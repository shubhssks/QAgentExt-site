# qagentext-cli 2.3.0

The companion command line for the QAgentExt Chrome extension. It runs saved
tests and regression plans headlessly in CI with the same engine as the
extension, and runs exported iOS flows through an Appium server.

Install (no account, no repository):

    npm install -g https://qagentext.netlify.app/cli/qagentext-cli-2.3.0.tgz
    npx playwright-core install chromium

Then:

    qagent run my-test.json --url https://staging.example.com
    qagent plan qagent-plan.json --url https://staging.example.com -o test-results
    qagent adapter run ios-appium my-flow.plan.json --target ipad-sim.target.json

Guide: https://qagentext.netlify.app/cli/
