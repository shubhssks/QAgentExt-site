/**
 * @fileoverview Suite Author module — Generate Suite flow: page summary →
 * candidate review modal → save selection to the library.
 * v2.0 adds executable form checks and main-document targeting.
 */

import { MSG } from '../../src/shared/constants.js';
import { generateSuite, toLibraryRecords } from '../../src/engine/test-author.js';

/**
 * @param {Object} ctx  Panel context.
 * @param {() => Array<Object>} ctx.getLibrary          Current library array (mutated in place on save).
 * @param {() => Promise<Object|undefined>} ctx.getTargetTab
 * @param {(filter?: string) => void} ctx.renderLibrary
 * @param {(entry: Object) => void} ctx.appendLog
 * @param {(text: string) => string} ctx.escapeHtml
 * @param {(library: Array<Object>) => Promise<void>} ctx.persistLibrary
 * @param {{ overlay: HTMLElement, rationale: HTMLElement, list: HTMLElement, folder: HTMLInputElement }} ctx.elements
 */
export function createSuiteAuthorModule(ctx) {
  const { getLibrary, getTargetTab, renderLibrary, appendLog, escapeHtml, persistLibrary, elements } = ctx;

  /** Candidates shown in the open modal, indexed by checkbox data-index. */
  let currentSuiteCandidates = [];

  async function openSuiteAuthor() {
    try {
      const tab = await getTargetTab();
      if (!tab?.id) { throw new Error('No active tab'); }

      const response = await chrome.tabs.sendMessage(tab.id, { type: MSG.GENERATE_SUITE }, { frameId: 0 });
      if (!response?.summary) { throw new Error('No page summary returned.'); }
      const suite = generateSuite(response.summary, { maxTests: 16, existingCommands: getLibrary().map(test => test.command) });
      currentSuiteCandidates = suite.tests;
      elements.rationale.textContent = suite.rationale;
      renderSuiteCandidates(suite.tests);
      elements.overlay.hidden = false;
    } catch (err) {
      appendLog({ type: 'error', timestamp: new Date().toISOString(), message: `Suite generation failed: ${err.message}` });
    }
  }

  function renderSuiteCandidates(candidates) {
    elements.list.innerHTML = '';
    const existingCommands = new Set(getLibrary().map(t => String(t.command).trim().toLowerCase()));
    const existingExact = new Set(getLibrary().map(t => String(t.command).trim()));

    candidates.forEach((c, i) => {
      const alreadySaved = c.steps?.length ? existingExact.has(String(c.command).trim()) : existingCommands.has(String(c.command).trim().toLowerCase());
      const row = document.createElement('label');
      row.className = `suite-author__row${alreadySaved ? ' suite-author__row--saved' : ''}`;
      row.innerHTML = `
        <input type="checkbox" class="suite-author__check" data-index="${i}"
          ${alreadySaved ? 'disabled' : ''} ${!alreadySaved && c.priority === 'high' ? 'checked' : ''}>
        <span class="suite-author__body">
          <span class="suite-author__title">
            ${escapeHtml(c.title)}
            <span class="suite-author__priority suite-author__priority--${c.priority}">${c.priority}</span>
            ${alreadySaved ? '<span class="suite-author__saved-note">already in library</span>' : ''}
          </span>
          <span class="suite-author__command">${escapeHtml(c.command)}</span>
          <span class="suite-author__rationale">${escapeHtml(c.rationale)}</span>
        </span>`;
      elements.list.appendChild(row);
    });
  }

  async function saveSelectedSuiteCandidates() {
    const checks = elements.list.querySelectorAll('.suite-author__check:checked');
    const selected = Array.from(checks)
      .map(cb => currentSuiteCandidates[Number((/** @type {HTMLElement} */ (cb)).dataset.index)])
      .filter(Boolean);

    if (selected.length === 0) {
      appendLog({ type: 'warn', timestamp: new Date().toISOString(), message: 'No candidate tests selected.' });
      return;
    }

    const library = getLibrary();
    const folder = (elements.folder.value || 'auto').trim();
    const { records, skipped } = toLibraryRecords(selected, {
      folder,
      existingCommands: library.map(t => t.command),
    });

    library.unshift(...records);
    await persistLibrary(library);
    renderLibrary();
    elements.overlay.hidden = true;

    const skippedNote = skipped.length ? ` (${skipped.length} skipped — already in library)` : '';
    appendLog({
      type: 'success',
      timestamp: new Date().toISOString(),
      message: `Saved ${records.length} generated test(s) to folder "${folder}"${skippedNote}. Review and run them from the Library.`,
    });
  }

  return { openSuiteAuthor, saveSelectedSuiteCandidates };
}
