/** @fileoverview CSV test-data editor for saved regression tests. */
import { parseCSV, toCSV } from '../../src/engine/data-driven.js';
import { normalizePlanDataSet } from '../../src/engine/plan-data.js';

/**
 * Create an editor that persists datasets on their saved library test.
 * @param {Object} ctx
 * @returns {{open: (test: Object) => void}}
 */
export function createTestDataModule(ctx) {
  function open(test) {
    const dialog = document.createElement('dialog');
    dialog.className = 'test-data';
    dialog.setAttribute('aria-labelledby', 'test-data-title');
    dialog.innerHTML = `
      <form method="dialog" class="test-data__header"><h2 id="test-data-title">Test data</h2><button class="btn btn--ghost btn--small" aria-label="Close test data" value="cancel">&times;</button></form>
      <p class="test-data__name"></p>
      <label class="test-data__field">CSV data<textarea id="test-data-csv" rows="8" spellcheck="false"></textarea></label>
      <label class="test-data__field">Import CSV<input id="test-data-file" type="file" accept=".csv,text/csv"></label>
      <p id="test-data-status" role="status" aria-live="polite"></p>
      <div class="test-data__actions"><button class="btn btn--secondary btn--small" id="test-data-remove" type="button">Remove data</button><button class="btn btn--primary btn--small" id="test-data-save" type="button">Save data</button></div>`;
    document.body.appendChild(dialog);
    dialog.querySelector('.test-data__name').textContent = test.name;
    const input = dialog.querySelector('#test-data-csv');
    input.value = test.dataSet ? toCSV(test.dataSet) : '';
    const status = dialog.querySelector('#test-data-status');
    let dataset = null;
    const validate = () => {
      try {
        dataset = normalizePlanDataSet(parseCSV(input.value, `${test.name} data`));
        status.textContent = `${dataset.rows.length} rows | ${dataset.columns.length} columns`;
      } catch (error) {
        dataset = null;
        status.textContent = error.message;
      }
      dialog.querySelector('#test-data-save').disabled = !dataset;
    };
    input.addEventListener('input', validate);
    dialog.querySelector('#test-data-file').addEventListener('change', async event => {
      const file = event.target.files[0];
      if (!file) { return; }
      if (file.size > 1024 * 1024) { status.textContent = 'CSV files must be 1 MB or smaller.'; return; }
      input.value = await file.text();
      validate();
    });
    dialog.querySelector('#test-data-save').addEventListener('click', async () => {
      validate();
      if (!dataset) { return; }
      try {
        await ctx.save(test.id, dataset);
        dialog.close();
      } catch (error) { status.textContent = `Could not save data: ${error.message}`; }
    });
    dialog.querySelector('#test-data-remove').disabled = !test.dataSet;
    dialog.querySelector('#test-data-remove').addEventListener('click', async () => {
      try { await ctx.save(test.id, null); dialog.close(); }
      catch (error) { status.textContent = `Could not remove data: ${error.message}`; }
    });
    dialog.addEventListener('close', () => dialog.remove());
    validate();
    dialog.showModal();
  }
  return { open };
}
