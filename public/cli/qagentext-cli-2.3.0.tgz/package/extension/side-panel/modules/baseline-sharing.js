/**
 * @fileoverview Baseline sharing module — export/import visual-baseline packs
 * so a team reviews visual diffs against the same goldens
 * (v1.5 F1, extracted verbatim from sidepanel.js; zero behavior change).
 */

import {
  buildBaselinePack,
  parseBaselinePack,
  diffBaselinePack,
  selectBaselinesToApply,
  diffA11yBaselinePack,
  selectA11yBaselinesToApply,
  A11Y_BASELINE_STORAGE_KEY,
} from '../../src/engine/baseline-pack.js';
import { BASELINE_STORAGE_PREFIX } from '../../src/engine/visual-regression.js';

/**
 * @param {Object} ctx  Panel context.
 * @param {(filter?: string) => void} ctx.renderLibrary
 * @param {(entry: Object) => void} ctx.appendLog
 * @param {(filename: string, content: string, type: string) => void} ctx.downloadFile
 * @param {{ librarySearch: HTMLInputElement }} ctx.elements
 */
export function createBaselineSharingModule(ctx) {
  const { renderLibrary, appendLog, downloadFile, elements } = ctx;

  /** Read every stored visual baseline as a key->baseline map. */
  function loadAllBaselines() {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (all) => {
        const map = {};
        for (const [key, value] of Object.entries(all || {})) {
          if (key.startsWith(BASELINE_STORAGE_PREFIX)) { map[key] = value; }
        }
        resolve(map);
      });
    });
  }

  /** Read the per-URL accessibility baselines (a single map, not prefixed keys). */
  function loadA11yBaselines() {
    return new Promise((resolve) => {
      chrome.storage.local.get(A11Y_BASELINE_STORAGE_KEY, (data) => {
        resolve((data && data[A11Y_BASELINE_STORAGE_KEY]) || {});
      });
    });
  }

  function renderBaselineSharing(container) {
    const wrap = document.createElement('div');
    wrap.className = 'auth-sessions';
    wrap.innerHTML = `
      <div class="auth-sessions__header">
        <strong>&#128444;&#65039; Baselines</strong>
        <span>
          <button class="btn btn--secondary btn--small" data-action="export-baselines" type="button"
            title="Download all visual baselines as a shareable pack">Export pack</button>
          <button class="btn btn--secondary btn--small" data-action="import-baselines" type="button"
            title="Import a teammate's baseline pack — reviewed before anything is overwritten">Import pack</button>
        </span>
      </div>
      <div class="auth-sessions__list" data-role="baseline-info"><small>Loading…</small></div>
      <input type="file" accept=".json,.qagent-baselines.json" data-role="baseline-file" hidden>
    `;
    container.appendChild(wrap);

    const info = wrap.querySelector('[data-role="baseline-info"]');
    Promise.all([loadAllBaselines(), loadA11yBaselines()]).then(([map, a11y]) => {
      const count = Object.keys(map).length;
      const a11yCount = Object.keys(a11y).length;
      info.innerHTML = `<small>${count} visual and ${a11yCount} accessibility baseline(s) stored locally. Share the pack via your repo so the team reviews against the same goldens.</small>`;
    });

    wrap.querySelector('[data-action="export-baselines"]')?.addEventListener('click', async () => {
      const map = await loadAllBaselines();
      const a11yBaselines = await loadA11yBaselines();
      const { pack, warnings } = buildBaselinePack(map, { a11yBaselines });
      warnings.forEach(w => appendLog({ type: 'warn', timestamp: new Date().toISOString(), message: `[Baselines] ${w}` }));
      if (pack.baselines.length === 0 && pack.a11yBaselines.length === 0) { return; }
      downloadFile(
        `qagent-baselines-${new Date().toISOString().slice(0, 10)}.qagent-baselines.json`,
        JSON.stringify(pack, null, 2),
        'application/json'
      );
      appendLog({ type: 'success', timestamp: new Date().toISOString(), message: `[Baselines] Exported ${pack.baselines.length} visual and ${pack.a11yBaselines.length} accessibility baseline(s).` });
    });

    const fileInput = /** @type {HTMLInputElement} */ (wrap.querySelector('[data-role="baseline-file"]'));
    wrap.querySelector('[data-action="import-baselines"]')?.addEventListener('click', () => fileInput?.click());
    fileInput?.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) { return; }
      try {
        const pack = parseBaselinePack(await file.text());
        const diff = diffBaselinePack(await loadAllBaselines(), pack);
        const a11yDiff = diffA11yBaselinePack(await loadA11yBaselines(), pack);

        const nothingVisual = diff.added.length === 0 && diff.changed.length === 0;
        const nothingA11y = a11yDiff.added.length === 0 && a11yDiff.changed.length === 0;
        if (nothingVisual && nothingA11y) {
          appendLog({ type: 'info', timestamp: new Date().toISOString(), message: `[Baselines] Nothing to import — all ${diff.identical + a11yDiff.identical} baseline(s) already match.` });
          return;
        }

        // Review before overwrite: changed baselines are the risky part, and an
        // accepted a11y baseline decides which violations stop failing a build,
        // so both kinds are counted in the same prompt.
        const totalAdded = diff.added.length + a11yDiff.added.length;
        const totalChanged = diff.changed.length + a11yDiff.changed.length;
        let mode = 'all';
        if (totalChanged > 0) {
          const overwrite = confirm(
            `Baseline pack from "${file.name}":\n\n` +
            `${diff.added.length} new visual, ${a11yDiff.added.length} new accessibility\n` +
            `${diff.changed.length} visual and ${a11yDiff.changed.length} accessibility baseline(s) DIFFER from yours\n` +
            `${diff.identical + a11yDiff.identical} identical\n\n` +
            `OK = replace the differing ones with the pack's versions\n` +
            `Cancel = import only the new ones`
          );
          mode = overwrite ? 'all' : 'new-only';
        } else if (!confirm(`Import ${totalAdded} new baseline(s) from "${file.name}"?`)) {
          return;
        }

        const writes = selectBaselinesToApply(diff, mode);
        // a11y baselines live in ONE map, so merge rather than replacing the key —
        // pages the pack does not mention must keep their local baseline.
        const a11yWrites = selectA11yBaselinesToApply(a11yDiff, mode);
        if (Object.keys(a11yWrites).length) {
          writes[A11Y_BASELINE_STORAGE_KEY] = { ...(await loadA11yBaselines()), ...a11yWrites };
        }
        await chrome.storage.local.set(writes);
        const detail = mode === 'new-only'
          ? `${totalAdded} added, ${totalChanged} differing kept local`
          : `${totalAdded} added, ${totalChanged} replaced`;
        appendLog({ type: 'success', timestamp: new Date().toISOString(), message: `[Baselines] Import complete: ${detail}.` });
        diff.changed.forEach(c => appendLog({
          type: mode === 'all' ? 'warn' : 'info',
          timestamp: new Date().toISOString(),
          message: `[Baselines] ${mode === 'all' ? 'replaced' : 'kept local'} "${c.testKey}" (yours: ${c.localCapturedAt || 'unknown'}, pack: ${c.capturedAt || 'unknown'})`,
        }));
        renderLibrary(elements.librarySearch.value.trim());
      } catch (err) {
        appendLog({ type: 'error', timestamp: new Date().toISOString(), message: `[Baselines] Import failed: ${err.message}` });
      }
    });
  }

  return { renderBaselineSharing };
}
