/**
 * @fileoverview iOS device runs from the side panel (2.2, Preview).
 *
 * The panel drives an iPhone, iPad or simulator through an Appium server —
 * normally on the same Mac — with the shared executor and QAgentExt's own
 * WebDriver client. Nothing here decides anything: capabilities, parsing and
 * checks come from `src/engine/adapters/ios-appium/flow.js`, execution from
 * `executor.js`. This module keeps state, renders it, and wires events.
 *
 * State lives here, not in the DOM, because the library re-renders its tabs
 * freely (a search keystroke, a tab switch): the script, the secrets typed for
 * this session and a run in progress must all survive that.
 */

import { IOS_CONFIG, LOG_TYPE } from '../../src/shared/constants.js';
import { createAppiumClient, checkAppiumServer } from '../../src/engine/adapters/ios-appium/appium-client.js';
import { runPlan } from '../../src/engine/adapters/ios-appium/executor.js';
import { prepareFlowRun, DEFAULT_TARGET } from '../../src/engine/adapters/ios-appium/flow.js';
import { planToScript, SCRIPT_EXAMPLES, SETTINGS_EXAMPLE } from '../../src/engine/adapters/ios-appium/script.js';
import { runPlanJUnitCases } from '../../src/engine/run-plan.js';
import { buildJUnitXml } from '../../src/engine/junit.js';

/**
 * A screenshot as an image source, or null. The bytes come from the Appium
 * server, which the panel does not control, so only strict base64 is embedded:
 * anything else could close the attribute it is written into.
 * @param {{ base64?: string } | undefined} artifact
 */
export function screenshotSrc(artifact) {
  const data = artifact && typeof artifact.base64 === 'string' ? artifact.base64.replace(/\s+/g, '') : '';
  return data && /^[A-Za-z0-9+/]+={0,2}$/.test(data) ? `data:image/png;base64,${data}` : null;
}

const STATUS_TEXT = Object.freeze({
  pending: 'Waiting', running: 'Running', pass: 'Passed', fail: 'Failed', 'soft-fail': 'Soft failure',
  flaky: 'Passed with soft failures', 'setup-failure': 'Could not start', interrupted: 'Stopped', skipped: 'Skipped',
});

/**
 * An iOS run as an entry of the panel's run history, so it appears in History,
 * Replay, Compare and the Insights dashboard like a web run. Step lines use the
 * orchestrator's "Step i/n:" form because Insights counts steps from it.
 * @param {{ plan: Object, result: Object, steps: Array<Object>, device: string, screenshot?: string|null }} input
 */
export function buildHistoryEntry({ plan, result, steps, device, screenshot = null }) {
  const item = result.cases[0];
  const iso = ms => new Date(ms).toISOString();
  const logs = [{ type: 'info', message: `iOS run on ${device}: ${plan.name}`, timestamp: iso(result.startedAt) }];
  let clock = result.startedAt;
  steps.forEach((step, index) => {
    if (step.status === 'pending') { return; } // never reached
    clock += step.durationMs || 0;
    const type = step.status === 'pass' ? 'success' : step.status === 'soft-fail' ? 'warn' : 'error';
    const outcome = STATUS_TEXT[step.status] || step.status;
    logs.push({ type, message: `Step ${index + 1}/${steps.length}: ${step.text} — ${outcome}${step.reason ? `: ${step.reason}` : ''}`, timestamp: iso(clock) });
  });
  logs.push({
    type: result.status === 'pass' ? 'success' : result.status === 'flaky' ? 'warn' : 'error',
    message: `Result: ${STATUS_TEXT[result.status] || result.status}${item.reason ? ` — ${item.reason}` : ''}`,
    timestamp: iso(result.finishedAt),
  });
  return {
    id: result.id,
    testId: `ios:${plan.id}`,
    command: `iOS flow: ${plan.name}`,
    status: result.status,
    timestamp: iso(result.finishedAt),
    screenshot,
    duration: item.durationMs,
    logs,
    report: null,
    adapter: 'ios-appium',
    device,
  };
}

/**
 * A device screenshot small enough to keep in run history: history lives in
 * chrome.storage.local alongside everything else, and a full-size simulator
 * PNG can be megabytes. Best effort: null wherever a canvas is unavailable.
 * @param {string} base64  PNG bytes.
 * @returns {Promise<string|null>}  A JPEG data URL.
 */
export function shrinkScreenshot(base64, { maxWidth = 480, quality = 0.6 } = {}) {
  return new Promise(resolve => {
    try {
      if (typeof Image === 'undefined' || typeof document === 'undefined') { resolve(null); return; }
      const canvas = document.createElement('canvas');
      const context = canvas.getContext && canvas.getContext('2d');
      if (!context) { resolve(null); return; }
      const image = new Image();
      image.onload = () => {
        try {
          const scale = Math.min(1, maxWidth / (image.naturalWidth || maxWidth));
          canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
          canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        } catch { resolve(null); }
      };
      image.onerror = () => resolve(null);
      image.src = `data:image/png;base64,${base64}`;
    } catch { resolve(null); }
  });
}

/**
 * @param {Object} ctx
 * @param {HTMLElement} ctx.container
 * @param {() => boolean} ctx.isVisible
 * @param {(text: any) => string} ctx.escapeHtml
 * @param {(name: string, content: string, type: string) => void} ctx.downloadFile
 * @param {(name: string, blob: Blob) => void} ctx.downloadBlob
 * @param {(entry: {type: string, message: string, timestamp: number}) => void} [ctx.log]
 * @param {(entry: Object) => void} [ctx.recordRun]  Adds a finished run to the panel's run history.
 * @param {(base64: string) => Promise<string|null>} [ctx.shrinkScreenshot]  Test seam for the canvas step.
 * @param {{ get: Function, set: Function }} [ctx.storage]
 */
export function createIosDeviceModule(ctx) {
  const store = ctx.storage || chrome.storage.local;
  const esc = ctx.escapeHtml;
  const state = {
    settings: { appiumUrl: IOS_CONFIG.DEFAULT_APPIUM_URL, softFailures: 'fail', ...DEFAULT_TARGET },
    draft: { name: '', script: '', flowId: '' },
    flows: [],
    runs: [],
    /** @type {Record<string, string>} Never persisted. */
    secrets: {},
    connection: { state: 'unknown', message: 'Not checked yet.' },
    problems: [],
    notice: '',
    /** @type {null | { status: string, message?: string, plan?: Object, steps: Array<Object>, result?: Object, artifacts: Record<string, Object> }} */
    run: null,
    stopRequested: false,
  };

  const ready = store.get([IOS_CONFIG.SETTINGS_KEY, IOS_CONFIG.FLOWS_KEY, IOS_CONFIG.DRAFT_KEY, IOS_CONFIG.RUNS_KEY]).then(data => {
    state.settings = { ...state.settings, ...(data[IOS_CONFIG.SETTINGS_KEY] || {}) };
    state.flows = Array.isArray(data[IOS_CONFIG.FLOWS_KEY]) ? data[IOS_CONFIG.FLOWS_KEY] : [];
    state.draft = { ...state.draft, ...(data[IOS_CONFIG.DRAFT_KEY] || {}) };
    state.runs = Array.isArray(data[IOS_CONFIG.RUNS_KEY]) ? data[IOS_CONFIG.RUNS_KEY] : [];
  }).catch(() => {});

  const log = (type, message) => { if (ctx.log) { ctx.log({ type, message: `iOS · ${message}`, timestamp: Date.now() }); } };
  const saveSettings = () => store.set({ [IOS_CONFIG.SETTINGS_KEY]: state.settings }).catch(() => {});
  let draftTimer = null;
  /** Typing is saved shortly after it pauses. */
  const saveDraft = () => {
    clearTimeout(draftTimer);
    draftTimer = setTimeout(() => store.set({ [IOS_CONFIG.DRAFT_KEY]: state.draft }).catch(() => {}), 300);
  };
  /** An explicit action (save, load, import) is saved at once: closing the panel right after must not lose it. */
  const saveDraftNow = () => {
    clearTimeout(draftTimer);
    return store.set({ [IOS_CONFIG.DRAFT_KEY]: state.draft }).catch(() => {});
  };
  const $ = id => /** @type {HTMLInputElement} */ (ctx.container.querySelector(`#${id}`));
  const isRunning = () => Boolean(state.run && (state.run.status === 'running' || state.run.status === 'checking'));

  // --- Rendering ---------------------------------------------------------------

  async function render() {
    await ready;
    if (!ctx.isVisible()) { return; }
    const s = state.settings;
    const app = s.targetType !== 'ios-safari';
    ctx.container.innerHTML = `
      <section class="ios-device" aria-label="iOS device runs">
        <header class="ios-device__intro">
          <h3>iOS device <span class="ios-device__badge">Preview</span></h3>
          <p>Run a flow on an iPhone, iPad or simulator through Appium on this Mac.</p>
        </header>

        <fieldset class="ios-device__group">
          <legend>Appium server</legend>
          <div class="ios-device__row">
            <input id="ios-appium-url" type="url" value="${esc(s.appiumUrl)}" aria-label="Appium server URL" spellcheck="false">
            <button type="button" class="btn btn--secondary btn--small" id="ios-check">Check</button>
          </div>
          <p id="ios-connection" class="ios-device__status ios-device__status--${esc(state.connection.state)}" role="status">${esc(state.connection.message)}</p>
          <details class="ios-device__help">
            <summary>First time on this Mac?</summary>
            <ol>
              <li>Install Xcode with an iOS simulator, and Node.js.</li>
              <li>Install Appium and its iOS driver:<code>npm install -g appium</code><code>appium driver install xcuitest</code></li>
              <li>Start it and leave it running: <code>appium</code></li>
              <li>Press Check. The first run on a new simulator takes a few minutes while Appium installs its helper app.</li>
            </ol>
          </details>
        </fieldset>

        <fieldset class="ios-device__group">
          <legend>Target</legend>
          <div class="ios-device__kinds" role="radiogroup" aria-label="What to test">
            <label><input type="radio" name="ios-kind" value="ios-app" ${app ? 'checked' : ''}>An app</label>
            <label><input type="radio" name="ios-kind" value="ios-safari" ${app ? '' : 'checked'}>A website in Safari</label>
          </div>
          <div class="ios-device__fields">
            <label>Device or simulator<input id="ios-device-name" value="${esc(s.deviceName)}" placeholder="iPhone 15" spellcheck="false"></label>
            <label>iOS version<input id="ios-platform-version" value="${esc(s.platformVersion)}" placeholder="Optional, e.g. 17.5" spellcheck="false"></label>
            <label ${app ? '' : 'hidden'} id="ios-bundle-field">App bundle id<input id="ios-bundle-id" value="${esc(s.bundleId)}" placeholder="com.example.app" spellcheck="false"></label>
            <label>UDID<input id="ios-udid" value="${esc(s.udid)}" placeholder="Real device only" spellcheck="false"></label>
          </div>
        </fieldset>

        <fieldset class="ios-device__group">
          <legend>Flow</legend>
          <div class="ios-device__row ios-device__row--wrap">
            <select id="ios-flows" aria-label="Saved iOS flows">
              <option value="">${state.flows.length ? 'Saved flows…' : 'No saved flows yet'}</option>
              ${state.flows.map(f => `<option value="${esc(f.id)}" ${f.id === state.draft.flowId ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}
            </select>
            <button type="button" class="btn btn--secondary btn--small" id="ios-example">Example</button>
            <button type="button" class="btn btn--secondary btn--small" id="ios-import">Import plan</button>
            <input type="file" id="ios-import-input" accept=".json,application/json" aria-label="Import a portable plan file" hidden>
          </div>
          <label class="ios-device__name">Name<input id="ios-flow-name" value="${esc(state.draft.name)}" placeholder="e.g. Sign in and open settings"></label>
          <textarea id="ios-script" class="ios-device__script" rows="9" spellcheck="false" aria-label="Flow steps, one per line" placeholder="launch app com.example.app&#10;tap &quot;Sign in&quot;&#10;expect text &quot;Welcome&quot; visible">${esc(state.draft.script)}</textarea>
          <details class="ios-device__help">
            <summary>Step syntax</summary>
            <ul class="ios-device__examples">${SCRIPT_EXAMPLES.map(e => `<li><code>${esc(e)}</code></li>`).join('')}</ul>
            <p>Text in quotes matches a label; <code>~id</code> is an accessibility id. Prefix <code>soft</code> to record a failure and carry on.</p>
          </details>
          <div id="ios-secrets">${renderSecrets()}</div>
          <div class="ios-device__row ios-device__row--wrap">
            <button type="button" class="btn btn--secondary btn--small" id="ios-save">Save flow</button>
            <button type="button" class="btn btn--secondary btn--small" id="ios-delete" ${state.draft.flowId ? '' : 'disabled'}>Delete</button>
            <button type="button" class="btn btn--secondary btn--small" id="ios-export">Export plan</button>
          </div>
          <p id="ios-notice" class="ios-device__notice" role="status">${esc(state.notice)}</p>
          <ul id="ios-problems" class="ios-device__problems" role="alert">${renderProblems()}</ul>
        </fieldset>

        <div class="ios-device__actions">
          <button type="button" class="btn btn--primary" id="ios-run" ${isRunning() ? 'disabled' : ''}>Run on device</button>
          <button type="button" class="btn btn--secondary" id="ios-stop" ${isRunning() ? '' : 'hidden'}>Stop</button>
          <label class="ios-device__toggle"><input type="checkbox" id="ios-soft-flaky" ${s.softFailures === 'flaky' ? 'checked' : ''}>Soft failures keep the run green</label>
        </div>

        <section id="ios-result" class="ios-device__result" aria-live="polite">${renderResult()}</section>
        ${renderRecent()}
      </section>`;
    bind();
  }

  function renderSecrets() {
    const names = Object.entries(planVariables()).filter(([, spec]) => spec.type === 'secret').map(([name]) => name);
    if (!names.length) { return ''; }
    return `<fieldset class="ios-device__secrets"><legend>Secrets for this session</legend>
      ${names.map(name => `<label>${esc(name)}<input type="password" data-secret="${esc(name)}" value="${esc(state.secrets[name] || '')}" autocomplete="off"></label>`).join('')}
      <p>Kept only while this panel is open. Never saved, exported or shown in results.</p></fieldset>`;
  }

  /** Variables declared by the current script, without running a full check. */
  function planVariables() {
    const prepared = prepareFlowRun({ script: state.draft.script, settings: state.settings, secrets: state.secrets });
    return prepared.plan.variables || {};
  }

  function renderProblems() {
    return state.problems.map(p => `<li>${p.line ? `<strong>Line ${p.line}:</strong> ` : ''}${esc(p.message)}</li>`).join('');
  }

  function renderResult() {
    const r = state.run;
    if (!r) { return ''; }
    if (r.status === 'checking') { return `<p class="ios-device__run-status">Checking the Appium server…</p>`; }
    if (r.status === 'blocked') { return `<p class="ios-device__run-status ios-device__run-status--fail">${esc(r.message)}</p>`; }
    const outcome = r.result ? r.result.status : 'running';
    const item = r.result && r.result.cases[0];
    const seconds = item ? ` in ${(item.durationMs / 1000).toFixed(1)}s` : '';
    const sessionNote = !r.result && r.session === 'starting' ? ' Starting the session; the first run on a simulator can take a few minutes.' : '';
    const stopping = !r.result && state.stopRequested ? ' Stopping after the current step…' : '';
    const evidence = item && item.attempts.at(-1) && item.attempts.at(-1).evidence;
    const failShot = evidence && evidence.screenshot && r.artifacts[evidence.screenshot];
    const failSrc = screenshotSrc(failShot);
    return `
      <p class="ios-device__run-status ios-device__run-status--${esc(outcome)}"><strong>${esc(STATUS_TEXT[outcome] || outcome)}</strong>${esc(seconds)}${esc(sessionNote)}${esc(stopping)}</p>
      ${item && item.reason ? `<p class="ios-device__reason">${esc(item.reason)}</p>` : ''}
      <ol class="ios-device__steps">
        ${r.steps.map(step => `
          <li class="ios-step ios-step--${esc(step.status)}">
            <span class="ios-step__status">${esc(STATUS_TEXT[step.status] || step.status)}</span>
            <code class="ios-step__text">${esc(step.text)}</code>
            ${step.durationMs !== undefined ? `<span class="ios-step__time">${esc(step.durationMs)} ms</span>` : ''}
            ${step.reason ? `<p class="ios-step__reason">${esc(step.reason)}</p>` : ''}
            ${step.screenshot && screenshotSrc(r.artifacts[step.screenshot]) ? `<img class="ios-device__shot" alt="Screenshot from this step" src="${screenshotSrc(r.artifacts[step.screenshot])}">` : ''}
          </li>`).join('')}
      </ol>
      ${failSrc ? `<figure class="ios-device__evidence"><img class="ios-device__shot" alt="The screen when the step failed" src="${failSrc}"><figcaption>The screen when the step failed.</figcaption></figure>` : ''}
      ${r.result ? `<div class="ios-device__row ios-device__row--wrap">
        <button type="button" class="btn btn--secondary btn--small" data-ios-download="json">Run JSON</button>
        <button type="button" class="btn btn--secondary btn--small" data-ios-download="junit">JUnit XML</button>
        ${failSrc ? '<button type="button" class="btn btn--secondary btn--small" data-ios-download="screenshot">Screenshot</button>' : ''}
        ${evidence && evidence.pageSource && r.artifacts[evidence.pageSource] ? '<button type="button" class="btn btn--secondary btn--small" data-ios-download="source">Element tree</button>' : ''}
      </div>` : ''}`;
  }

  function renderRecent() {
    if (!state.runs.length) { return ''; }
    return `<details class="ios-device__recent"><summary>Recent iOS runs (${state.runs.length})</summary><ul>
      ${state.runs.map(run => `<li><span class="ios-step__status">${esc(STATUS_TEXT[run.status] || run.status)}</span> ${esc(run.name)} <small>${esc(new Date(run.finishedAt).toLocaleString())} · ${esc(run.device)}</small></li>`).join('')}
    </ul></details>`;
  }

  /** Update only the live parts, so typing in the form is never interrupted. */
  function refreshLive() {
    if (!ctx.isVisible()) { return; }
    const result = $('ios-result');
    if (!result) { return; }
    result.innerHTML = renderResult();
    bindDownloads();
    const runBtn = $('ios-run');
    const stopBtn = $('ios-stop');
    if (runBtn) { runBtn.disabled = isRunning(); }
    if (stopBtn) { stopBtn.hidden = !isRunning(); }
    const connection = $('ios-connection');
    if (connection) {
      connection.textContent = state.connection.message;
      connection.className = `ios-device__status ios-device__status--${state.connection.state}`;
    }
    const problems = $('ios-problems');
    if (problems) { problems.innerHTML = renderProblems(); }
    const notice = $('ios-notice');
    if (notice) { notice.textContent = state.notice; }
  }

  // --- Events -----------------------------------------------------------------

  function bind() {
    const field = (id, key, after) => $(id)?.addEventListener('input', event => {
      state.settings[key] = /** @type {HTMLInputElement} */ (event.target).value;
      saveSettings();
      if (after) { after(); }
    });
    field('ios-appium-url', 'appiumUrl', () => { state.connection = { state: 'unknown', message: 'Not checked yet.' }; refreshLive(); });
    field('ios-device-name', 'deviceName');
    field('ios-platform-version', 'platformVersion');
    field('ios-bundle-id', 'bundleId');
    field('ios-udid', 'udid');
    ctx.container.querySelectorAll('input[name="ios-kind"]').forEach(radio => radio.addEventListener('change', event => {
      state.settings.targetType = /** @type {HTMLInputElement} */ (event.target).value;
      saveSettings();
      const bundle = $('ios-bundle-field');
      if (bundle) { bundle.hidden = state.settings.targetType === 'ios-safari'; }
    }));
    $('ios-soft-flaky')?.addEventListener('change', event => {
      state.settings.softFailures = /** @type {HTMLInputElement} */ (event.target).checked ? 'flaky' : 'fail';
      saveSettings();
    });
    $('ios-check')?.addEventListener('click', () => { checkConnection(); });

    $('ios-flow-name')?.addEventListener('input', event => { state.draft.name = /** @type {HTMLInputElement} */ (event.target).value; saveDraft(); });
    $('ios-script')?.addEventListener('input', event => {
      const before = Object.keys(planVariables()).join();
      state.draft.script = /** @type {HTMLTextAreaElement} */ (event.target).value;
      saveDraft();
      // Re-render the secret fields only when the declarations change.
      if (Object.keys(planVariables()).join() !== before) {
        const holder = $('ios-secrets');
        if (holder) { holder.innerHTML = renderSecrets(); bindSecrets(); }
      }
    });
    bindSecrets();

    $('ios-flows')?.addEventListener('change', event => {
      const flow = state.flows.find(f => f.id === /** @type {HTMLSelectElement} */ (event.target).value);
      if (!flow) { return; }
      state.draft = { name: flow.name, script: flow.script, flowId: flow.id };
      if (flow.targetType) { state.settings.targetType = flow.targetType; saveSettings(); }
      state.problems = [];
      state.notice = `Loaded "${flow.name}".`;
      saveDraftNow();
      render();
    });
    $('ios-example')?.addEventListener('click', () => {
      state.draft = { name: 'Settings smoke', script: SETTINGS_EXAMPLE, flowId: '' };
      state.settings.targetType = 'ios-app';
      if (!state.settings.bundleId) { state.settings.bundleId = 'com.apple.Preferences'; }
      state.problems = [];
      state.notice = 'Loaded an example that runs on any simulator: Apple\'s Settings app.';
      saveSettings();
      saveDraftNow();
      render();
    });
    $('ios-import')?.addEventListener('click', () => $('ios-import-input')?.click());
    $('ios-import-input')?.addEventListener('change', event => importPlan(/** @type {HTMLInputElement} */ (event.target).files?.[0]));
    $('ios-save')?.addEventListener('click', saveFlow);
    $('ios-delete')?.addEventListener('click', deleteFlow);
    $('ios-export')?.addEventListener('click', exportPlan);
    $('ios-run')?.addEventListener('click', () => { run(); });
    $('ios-stop')?.addEventListener('click', () => { state.stopRequested = true; refreshLive(); });
    bindDownloads();
  }

  function bindSecrets() {
    ctx.container.querySelectorAll('input[data-secret]').forEach(input => input.addEventListener('input', event => {
      const el = /** @type {HTMLInputElement} */ (event.target);
      state.secrets[el.dataset.secret] = el.value;
    }));
  }

  function bindDownloads() {
    ctx.container.querySelectorAll('[data-ios-download]').forEach(btn => btn.addEventListener('click', () => {
      download(/** @type {HTMLElement} */ (btn).dataset.iosDownload);
    }));
  }

  // --- Actions ----------------------------------------------------------------

  async function checkConnection() {
    state.connection = { state: 'checking', message: 'Checking…' };
    refreshLive();
    const result = await checkAppiumServer(state.settings.appiumUrl);
    const version = result.ok && result.status && result.status.build && result.status.build.version;
    state.connection = result.ok
      ? { state: 'ok', message: `Connected${version ? ` to Appium ${version}` : ''}.` }
      : { state: 'down', message: result.reason || 'The Appium server did not answer.' };
    refreshLive();
    return result;
  }

  async function saveFlow() {
    const name = state.draft.name.trim();
    if (!name) { state.problems = [{ line: 0, field: 'script', message: 'Give the flow a name before saving it.' }]; refreshLive(); return; }
    const id = state.draft.flowId || `ios-${Date.now()}`;
    const flow = { id, name, script: state.draft.script, targetType: state.settings.targetType, updatedAt: Date.now() };
    state.flows = [flow, ...state.flows.filter(f => f.id !== id)].slice(0, IOS_CONFIG.MAX_FLOWS);
    state.draft.flowId = id;
    state.problems = [];
    state.notice = `Saved "${name}".`;
    await store.set({ [IOS_CONFIG.FLOWS_KEY]: state.flows }).catch(() => {});
    await saveDraftNow();
    render();
  }

  async function deleteFlow() {
    const flow = state.flows.find(f => f.id === state.draft.flowId);
    if (!flow || !confirm(`Delete the saved flow "${flow.name}"?`)) { return; }
    state.flows = state.flows.filter(f => f.id !== flow.id);
    state.draft.flowId = '';
    state.notice = `Deleted "${flow.name}". The text is still in the editor.`;
    await store.set({ [IOS_CONFIG.FLOWS_KEY]: state.flows }).catch(() => {});
    saveDraftNow();
    render();
  }

  async function importPlan(file) {
    if (!file) { return; }
    let plan;
    try { plan = JSON.parse(await file.text()); } catch {
      state.problems = [{ line: 0, field: 'script', message: `${file.name} is not valid JSON.` }];
      refreshLive();
      return;
    }
    const { script, unsupported } = planToScript(plan);
    if (unsupported.length) {
      state.problems = [{ line: 0, field: 'script', message: `This plan has steps the editor cannot show without losing them: ${unsupported.map(u => `${u.id} (${u.action})`).join(', ')}. Run it with the CLI instead.` }];
      refreshLive();
      return;
    }
    state.draft = { name: plan.name || file.name.replace(/\.json$/i, ''), script, flowId: '' };
    if (plan.targetType === 'ios-safari' || plan.targetType === 'ios-app') { state.settings.targetType = plan.targetType; saveSettings(); }
    state.problems = [];
    state.notice = `Imported "${state.draft.name}". Save it to keep it.`;
    saveDraftNow();
    render();
  }

  function exportPlan() {
    const prepared = prepareFlowRun({ script: state.draft.script, name: state.draft.name, settings: state.settings, secrets: {} });
    const scriptProblems = prepared.problems.filter(p => p.field === 'script');
    if (scriptProblems.length) { state.problems = scriptProblems; refreshLive(); return; }
    ctx.downloadFile(`${prepared.plan.id}.plan.json`, JSON.stringify(prepared.plan, null, 2), 'application/json');
    state.notice = 'Exported a portable plan. It contains secret names, never their values.';
    refreshLive();
  }

  function download(kind) {
    const r = state.run;
    if (!r || !r.result) { return; }
    const base = (r.plan && r.plan.id) || 'ios-run';
    const evidence = r.result.cases[0].attempts.at(-1)?.evidence || {};
    if (kind === 'json') { ctx.downloadFile(`${base}.run.json`, JSON.stringify(r.result, null, 2), 'application/json'); }
    if (kind === 'junit') { ctx.downloadFile(`${base}.junit.xml`, buildJUnitXml({ cases: runPlanJUnitCases(r.result), suiteName: r.plan.name }), 'application/xml'); }
    if (kind === 'source' && r.artifacts[evidence.pageSource]) { ctx.downloadFile(`${base}.source.xml`, r.artifacts[evidence.pageSource].text, 'application/xml'); }
    if (kind === 'screenshot' && r.artifacts[evidence.screenshot]) {
      const bytes = Uint8Array.from(atob(r.artifacts[evidence.screenshot].base64), c => c.charCodeAt(0));
      ctx.downloadBlob(`${base}.png`, new Blob([bytes], { type: 'image/png' }));
    }
  }

  async function run() {
    if (isRunning()) { return; }
    await ready;
    const prepared = prepareFlowRun({
      script: state.draft.script, name: state.draft.name, settings: state.settings,
      secrets: state.secrets, newCommandTimeoutS: IOS_CONFIG.NEW_COMMAND_TIMEOUT_S,
    });
    state.problems = prepared.problems;
    state.notice = '';
    if (!prepared.ok) { refreshLive(); return; }

    state.run = { status: 'checking', steps: [], artifacts: {} };
    refreshLive();
    const server = await checkConnection();
    if (!server.ok) {
      state.run = { status: 'blocked', message: `Not started: ${server.reason}`, steps: [], artifacts: {} };
      refreshLive();
      return;
    }

    const { plan, capabilities, env } = prepared;
    const device = capabilities['appium:deviceName'] || capabilities['appium:udid'] || 'device';
    const client = createAppiumClient(state.settings.appiumUrl);
    state.stopRequested = false;
    state.run = {
      status: 'running', plan, session: 'starting', artifacts: {},
      steps: plan.steps.map(step => ({ id: step.id, text: step.description || step.action, status: 'pending' })),
    };
    refreshLive();
    log(LOG_TYPE.INFO, `Starting "${plan.name}" on ${device}.`);

    const result = await runPlan(plan, {
      createSession: caps => client.createSession(caps),
      capabilities,
      env,
      softFailures: state.settings.softFailures === 'flaky' ? 'flaky' : 'fail',
      isCancelled: () => state.stopRequested,
      saveArtifact: async artifact => {
        const ref = `artifact:${artifact.name}`;
        state.run.artifacts[ref] = artifact;
        return ref;
      },
      onEvent: event => {
        if (event.type === 'session') { state.run.session = event.status; }
        const step = state.run.steps.find(s => s.id === event.id);
        if (event.type === 'step-start' && step) { step.status = 'running'; }
        if (event.type === 'step-end' && step) {
          Object.assign(step, { status: event.status, durationMs: event.durationMs, reason: event.reason });
          log(event.status === 'pass' ? LOG_TYPE.SUCCESS : event.status === 'soft-fail' ? LOG_TYPE.WARN : LOG_TYPE.ERROR,
            `${step.text} — ${STATUS_TEXT[event.status] || event.status}${event.reason ? `: ${event.reason}` : ''}`);
        }
        refreshLive();
      },
    });

    // Screenshot steps carry their artifact on the recorded step.
    for (const recorded of result.cases[0].steps) {
      const step = state.run.steps.find(s => s.id === recorded.id);
      if (step && recorded.screenshot) { step.screenshot = recorded.screenshot; }
    }
    state.run.status = 'done';
    state.run.result = result;
    const item = result.cases[0];
    log(result.status === 'pass' ? LOG_TYPE.SUCCESS : result.status === 'flaky' ? LOG_TYPE.WARN : LOG_TYPE.ERROR,
      `"${plan.name}": ${STATUS_TEXT[result.status] || result.status}${item.reason ? ` — ${item.reason}` : ''}`);
    state.runs = [{ id: result.id, name: plan.name, status: result.status, finishedAt: result.finishedAt, device }, ...state.runs].slice(0, IOS_CONFIG.RUNS_LIMIT);
    store.set({ [IOS_CONFIG.RUNS_KEY]: state.runs }).catch(() => {});
    if (ctx.isVisible()) { render(); }

    // Into the panel's run history too, with a small copy of the failure
    // screenshot, so History, Replay, Compare and Insights all see the run.
    if (ctx.recordRun) {
      const evidence = item.attempts.at(-1)?.evidence;
      const failShot = evidence && evidence.screenshot && state.run.artifacts[evidence.screenshot];
      const screenshot = failShot && screenshotSrc(failShot) ? await (ctx.shrinkScreenshot || shrinkScreenshot)(failShot.base64) : null;
      try { ctx.recordRun(buildHistoryEntry({ plan, result, steps: state.run.steps, device, screenshot })); } catch { /* history is best effort */ }
    }
  }

  return { render, run, checkConnection, isRunning };
}
