/**
 * @fileoverview Dashboard module — suite-health command center (v1.5 C1).
 *
 * Renders a Dashboard tab from the panel's existing run history: pass-rate,
 * ROI/time-saved, slowest and flakiest tests, and a recent-runs sparkline.
 * Everything is computed on render — no derived analytics are stored
 * (storage-quota guardrail). Exports an executive markdown report.
 */

import { computeSuiteHealth, renderSuiteHealthMarkdown } from '../../src/engine/analytics-engine.js';
import { buildInsightsModel, renderInsightsMarkdown } from '../../src/engine/insights.js';

/** Storage key holding the v1.7 Y4 per-page accessibility conformance trend. */
const A11Y_TREND_KEY = 'qagent_a11y_trend';

/**
 * @param {Object} ctx  Panel context.
 * @param {() => Array<Object>} ctx.getRunHistory
 * @param {(text: string) => string} ctx.escapeHtml
 * @param {(filename: string, content: string, type: string) => void} ctx.downloadFile
 * @param {(entry: Object) => void} ctx.appendLog
 */
export function createDashboardModule(ctx) {
  const { getRunHistory, escapeHtml, downloadFile, appendLog } = ctx;

  function renderDashboard(container) {
    const model = computeSuiteHealth(getRunHistory());

    const host = document.createElement('div');
    host.className = 'dashboard';

    if (model.totalRuns === 0) {
      host.innerHTML = '<div class="dashboard__empty">No runs yet. Run a few checks and your suite health shows up here.</div>';
      container.appendChild(host);
      return;
    }

    const spark = model.recentTrend
      .map((s) => `<span class="dashboard__spark dashboard__spark--${s}" title="${s}"></span>`)
      .join('');

    const slowRows = model.slowest.length
      ? model.slowest.map((s) => `
          <div class="dashboard__row">
            <span class="dashboard__row-main">${escapeHtml(s.command)}</span>
            <span class="dashboard__row-meta">${s.avgMs} ms · ${s.runs} run(s)</span>
          </div>`).join('')
      : '<div class="dashboard__row-empty">No timing data yet.</div>';

    const flakyRows = model.flakiest.length
      ? model.flakiest.map((f) => `
          <div class="dashboard__row">
            <span class="dashboard__row-main">${escapeHtml(f.command)}</span>
            <span class="dashboard__row-meta dashboard__row-meta--warn">${f.failRate}% fail · ${f.runs} runs</span>
          </div>`).join('')
      : '<div class="dashboard__row-empty">No flaky tests detected.</div>';

    host.innerHTML = `
      <div class="dashboard__tiles">
        <div class="dashboard__tile">
          <span class="dashboard__tile-value dashboard__tile-value--${model.passRate >= 80 ? 'good' : 'warn'}">${model.passRate}%</span>
          <span class="dashboard__tile-label">Pass rate</span>
        </div>
        <div class="dashboard__tile">
          <span class="dashboard__tile-value">${model.totalRuns}</span>
          <span class="dashboard__tile-label">Runs (${model.passed}✓ / ${model.failed}✗)</span>
        </div>
        <div class="dashboard__tile">
          <span class="dashboard__tile-value">${model.estHoursSaved}h</span>
          <span class="dashboard__tile-label">Est. time saved</span>
        </div>
        <div class="dashboard__tile">
          <span class="dashboard__tile-value">${model.avgDurationMs}<small>ms</small></span>
          <span class="dashboard__tile-label">Avg duration</span>
        </div>
      </div>
      <div class="dashboard__trend">
        <span class="dashboard__section-label">Recent runs</span>
        <div class="dashboard__sparkline">${spark}</div>
      </div>
      <div class="dashboard__section">
        <span class="dashboard__section-label">Slowest</span>
        ${slowRows}
      </div>
      <div class="dashboard__section">
        <span class="dashboard__section-label">Flakiest</span>
        ${flakyRows}
      </div>
      <div class="dashboard__reco">💡 ${escapeHtml(model.recommendation)}</div>
      <button class="btn btn--secondary btn--small" data-action="export-report" type="button">Export report</button>
    `;
    container.appendChild(host);
    renderInsights(container);

    host.querySelector('[data-action="export-report"]')?.addEventListener('click', () => {
      const md = renderSuiteHealthMarkdown(computeSuiteHealth(getRunHistory()));
      downloadFile(`qagent-suite-health-${new Date().toISOString().slice(0, 10)}.md`, md, 'text/markdown');
      appendLog({ type: 'success', timestamp: new Date().toISOString(), message: 'Suite-health report exported.' });
    });
  }

  /**
   * v1.7 I1: Insights — value (ROI) plus the accessibility posture recorded by
   * the Y4 conformance trend. Live storage read so it reflects the latest scans;
   * computed on render, nothing derived is stored.
   * @param {HTMLElement} container
   */
  function renderInsights(container) {
    const host = document.createElement('div');
    host.className = 'dashboard dashboard--insights';
    container.appendChild(host);

    chrome.storage.local.get([A11Y_TREND_KEY], (data) => {
      const model = buildInsightsModel({
        runHistory: getRunHistory(),
        trendMap: (data && data[A11Y_TREND_KEY]) || {},
      });
      if (!model.hasData) { host.remove(); return; }

      const a11y = model.a11y;
      const pageRows = a11y.pages.map((pg) => [
        '<div class="dashboard__row">',
        `<span class="dashboard__row-main">${escapeHtml(pg.url)}</span>`,
        `<span class="dashboard__row-meta">${escapeHtml(pg.sparkline)} ${pg.score}/100 · ${escapeHtml(pg.direction)}</span>`,
        '</div>',
      ].join('')).join('');

      const posture = a11y.overall
        ? [
          '<div class="dashboard__tiles">',
          '<div class="dashboard__tile">',
          `<span class="dashboard__tile-value dashboard__tile-value--${a11y.overall.avgScore >= 80 ? 'good' : 'warn'}">${a11y.overall.avgScore}</span>`,
          '<span class="dashboard__tile-label">Avg conformance</span>',
          '</div>',
          '<div class="dashboard__tile">',
          `<span class="dashboard__tile-value">${a11y.overall.conformantPages}/${a11y.pagesAudited}</span>`,
          '<span class="dashboard__tile-label">Pages without blockers</span>',
          '</div>',
          '<div class="dashboard__tile">',
          `<span class="dashboard__tile-value dashboard__tile-value--${a11y.overall.regressing ? 'warn' : 'good'}">${a11y.overall.regressing}</span>`,
          '<span class="dashboard__tile-label">Regressing pages</span>',
          '</div>',
          '</div>',
          pageRows,
        ].join('')
        : '<div class="dashboard__row-empty">No accessibility scans recorded yet. Run "scan accessibility" to start tracking.</div>';

      const feed = model.activity.length
        ? model.activity.map((e) => [
          '<div class="dashboard__row">',
          `<span class="dashboard__row-main">${escapeHtml(e.command)}</span>`,
          `<span class="dashboard__row-meta dashboard__row-meta--${e.status === 'fail' ? 'warn' : 'ok'}">${escapeHtml(e.status)} · ${escapeHtml(e.relativeTime || '')}</span>`,
          '</div>',
        ].join('')).join('')
        : '<div class="dashboard__row-empty">No activity yet.</div>';

      host.innerHTML = [
        '<div class="dashboard__section">',
        '<span class="dashboard__section-label">Accessibility posture</span>',
        posture,
        '</div>',
        '<div class="dashboard__section">',
        '<span class="dashboard__section-label">Value</span>',
        '<div class="dashboard__row">',
        `<span class="dashboard__row-main">${model.roi.totalSteps} steps automated across ${model.roi.totalRuns} run(s)</span>`,
        `<span class="dashboard__row-meta">~${model.roi.hoursSaved}h saved · ${escapeHtml(model.roi.efficiencyGain)} pass</span>`,
        '</div>',
        '</div>',
        '<div class="dashboard__section">',
        '<span class="dashboard__section-label">Recent activity</span>',
        feed,
        '</div>',
        '<button class="btn btn--secondary btn--small" data-action="export-insights" type="button">Export insights</button>',
      ].join('');

      host.querySelector('[data-action="export-insights"]')?.addEventListener('click', () => {
        downloadFile(
          `qagent-insights-${new Date().toISOString().slice(0, 10)}.md`,
          renderInsightsMarkdown(model),
          'text/markdown'
        );
        appendLog({ type: 'success', timestamp: new Date().toISOString(), message: 'Insights report exported.' });
      });
    });
  }

  return { renderDashboard };
}
