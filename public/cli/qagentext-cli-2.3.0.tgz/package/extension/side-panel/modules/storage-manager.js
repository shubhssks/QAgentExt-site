/**
 * @fileoverview Storage-manager module — per-category storage usage with a
 * near-quota warning and per-category clear (v1.5 P3). Rendered in the
 * Dashboard tab.
 */

import { computeStorageBreakdown, formatBytes, STORAGE_WARN_FRACTION } from '../../src/engine/storage-usage.js';

const BASELINE_PREFIX = 'qagent_visual_baseline_';

/** Fixed-key categories. Baselines are prefix-based (enumerated at read time). */
const FIXED_CATEGORIES = [
  { name: 'Library', keys: ['qagent_library', 'qagent_blocks', 'qagent_suites'] },
  { name: 'Run history', keys: ['qagent_history'] },
  { name: 'Hotspots', keys: ['qagent_heatmap_events'] },
  { name: 'Auth sessions', keys: ['qagent_session_snapshots'] },
  { name: 'Monitors', keys: ['qagent_schedules', 'qagent_monitor_history'] },
  { name: 'Profiles', keys: ['qagent_profiles'] },
];

/**
 * @param {Object} ctx
 * @param {(entry: Object) => void} ctx.appendLog
 */
export function createStorageManagerModule(ctx) {
  const { appendLog } = ctx;

  const getBytes = (keys) => new Promise((resolve) => {
    const api = /** @type {any} */ (chrome.storage.local);
    if (typeof api.getBytesInUse !== 'function') { resolve(0); return; }
    api.getBytesInUse(keys, (bytes) => resolve(Number(bytes) || 0));
  });

  const allKeys = () => new Promise((resolve) => {
    chrome.storage.local.get(null, (all) => resolve(Object.keys(all || {})));
  });

  /** Measure bytes per category, including prefix-based baselines. */
  async function measure() {
    const keys = await allKeys();
    const baselineKeys = keys.filter((k) => k.startsWith(BASELINE_PREFIX));

    /** @type {Object<string, number>} */
    const byteCounts = {};
    for (const cat of FIXED_CATEGORIES) {
      byteCounts[cat.name] = await getBytes(cat.keys);
    }
    byteCounts.Baselines = baselineKeys.length ? await getBytes(baselineKeys) : 0;

    return { byteCounts, baselineKeys };
  }

  /** Resolve the storage keys backing a category (for clearing). */
  function keysForCategory(name, baselineKeys) {
    if (name === 'Baselines') { return baselineKeys; }
    const cat = FIXED_CATEGORIES.find((c) => c.name === name);
    return cat ? cat.keys : [];
  }

  async function renderStorage(container) {
    const host = document.createElement('div');
    host.className = 'storage-manager';
    host.innerHTML = '<span class="dashboard__section-label">Storage</span><div class="storage-manager__loading"><small>Measuring…</small></div>';
    container.appendChild(host);

    const { byteCounts, baselineKeys } = await measure();
    const model = computeStorageBreakdown(byteCounts);

    const rows = model.categories
      .filter((c) => c.bytes > 0)
      .map((c) => `
        <div class="storage-manager__row">
          <span class="storage-manager__name">${c.name}</span>
          <span class="storage-manager__bar"><span class="storage-manager__bar-fill" style="width:${Math.min(100, c.pct)}%"></span></span>
          <span class="storage-manager__bytes">${formatBytes(c.bytes)}</span>
          <button class="btn--icon storage-manager__clear" title="Clear ${c.name}" data-category="${c.name}">&#128465;&#65039;</button>
        </div>`).join('') || '<div class="storage-manager__empty"><small>No stored data yet.</small></div>';

    host.innerHTML = `
      <span class="dashboard__section-label">Storage</span>
      <div class="storage-manager__total${model.warn ? ' storage-manager__total--warn' : ''}">
        ${formatBytes(model.totalBytes)} of ${formatBytes(model.quotaBytes)} used (${model.pctUsed}%)${model.warn ? ` &middot; ⚠ over ${Math.round(STORAGE_WARN_FRACTION * 100)}%` : ''}
      </div>
      ${rows}
    `;

    host.querySelectorAll('.storage-manager__clear').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const name = /** @type {HTMLElement} */ (btn).dataset.category;
        if (!confirm(`Clear all "${name}" data? This cannot be undone.`)) { return; }
        const keys = keysForCategory(name, baselineKeys);
        await new Promise((resolve) => chrome.storage.local.remove(keys, () => resolve(undefined)));
        appendLog({ type: 'success', timestamp: new Date().toISOString(), message: `[Storage] Cleared "${name}".` });
        host.remove();
        renderStorage(container);
      });
    });
  }

  return { renderStorage };
}
