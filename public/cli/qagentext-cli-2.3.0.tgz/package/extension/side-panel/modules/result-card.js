/**
 * @fileoverview Result-card rendering module (v1.7 F1).
 *
 * Owns how a run result is DRAWN: the findings list, triage cards, severity
 * badges, the a11y fix hints and the contrast heatmap. Panel-owned state and
 * the decision of WHEN to show a result stay in sidepanel.js (showResult) —
 * this module only renders what it is handed, which is why its context is small.
 */

import { REPORT_OWNER_OPTIONS, REPORT_SEVERITY_OPTIONS } from '../../src/engine/reporting.js';
import { buildContrastHeatmap } from '../../src/engine/vision-sim.js';

/** Pure severity -> badge tone mapping; also used by the assertion list. */
export function badgeToneForSeverity(severity) {
  switch (severity) {
    case 'blocker':
      return 'critical';
    case 'high':
      return 'serious';
    case 'medium':
      return 'moderate';
    case 'low':
      return 'minor';
    default:
      return severity || 'neutral';
  }
}


/**
 * @param {Object} ctx  Panel context.
 * @param {(text: string) => string} ctx.escapeHtml
 * @param {(findingId: string, patch: Object) => Promise<void>} ctx.updateFindingTriage
 * @param {{ resultDetails: HTMLElement }} ctx.elements
 */
export function createResultCardModule(ctx) {
  const { escapeHtml, updateFindingTriage, elements } = ctx;
  const { resultDetails } = elements;

function renderResultDetails(report, runResult = null) {
  resultDetails.hidden = true;
  resultDetails.innerHTML = '';

  if (!report || !Array.isArray(report.findings) || report.findings.length === 0) {
    return;
  }

  const summaryRow = document.createElement('div');
  summaryRow.className = 'result__report-summary';
  summaryRow.innerHTML = `
    <div class="result__report-card">
      <span class="result__report-label">Urgency</span>
      <div class="result__report-value">${escapeHtml(report.nextAction)}</div>
    </div>
    <div class="result__report-card">
      <span class="result__report-label">Owners</span>
      <div class="result__report-value">${escapeHtml(report.owners.join(', '))}</div>
    </div>
  `;

  const badgeRow = document.createElement('div');
  badgeRow.className = 'result__details-summary';
  badgeRow.appendChild(createResultBadge(`${report.findings.length} issue${report.findings.length === 1 ? '' : 's'}`, 'neutral'));
  REPORT_SEVERITY_OPTIONS.forEach(level => {
    const count = report.severityCounts[level] || 0;
    if (count > 0) {
      badgeRow.appendChild(createResultBadge(`${count} ${level}`, badgeToneForSeverity(level)));
    }
  });

  const intro = document.createElement('p');
  intro.className = 'result__finding-message';
  intro.textContent = `Coverage: ${report.coverageSummary}. Triage each issue with severity and owner, then rerun after the highest-risk fix.`;

  // v1.7 Y6: rank contrast failures by how far short of WCAG 1.4.3 they fall,
  // so the worst-readable text is obvious rather than buried in the finding list.
  // Derived here from the run's aggregated findings: the soft-fail a11y suite
  // replaces per-step details, so the panel is the reliable single source.
  const heatmap = buildContrastHeatmap(runResult?.details?.findings || []);
  if (heatmap && heatmap.count > 0) {
    const host = document.createElement('div');
    host.className = 'result__contrast-heatmap';
    const rows = heatmap.regions.map((r) => [
      '<div class="dashboard__row">',
      `<span class="dashboard__row-main">${escapeHtml(r.selector || '(element)')}</span>`,
      `<span class="dashboard__row-meta dashboard__row-meta--warn">${r.ratio}:1 vs ${r.required}:1 required · ${escapeHtml(r.band)} · WCAG ${escapeHtml(r.wcag)}</span>`,
      r.suggestion
        ? `<span class="dashboard__row-meta">Try ${escapeHtml(r.suggestion.hex)} — ${r.suggestion.ratio}:1</span>`
        : '',
      '</div>',
    ].join('')).join('');
    host.innerHTML = `<span class="dashboard__section-label">Contrast heatmap (${heatmap.count})</span>${rows}`;
    resultDetails.appendChild(host);
  }

  const list = document.createElement('div');
  list.className = 'result__finding-list';

  report.findings.slice(0, 8).forEach(finding => {
    list.appendChild(createFindingCard(finding));
  });

  if (report.findings.length > 8) {
    const more = document.createElement('p');
    more.className = 'result__finding-message';
    more.textContent = `Showing 8 of ${report.findings.length} findings. Fix the highest-severity items first, then rerun the scan.`;
    list.appendChild(more);
  }

  resultDetails.appendChild(summaryRow);
  if (report.failureTriage) {
    resultDetails.appendChild(createFailureTriageCard(report.failureTriage));
  }
  resultDetails.appendChild(badgeRow);
  resultDetails.appendChild(intro);
  resultDetails.appendChild(list);
  resultDetails.hidden = false;
}

function createFailureTriageCard(triage) {
  const card = document.createElement('div');
  card.className = 'result__triage';

  const title = document.createElement('div');
  title.className = 'result__triage-title';
  title.textContent = triage.title || 'Failure triage';

  const category = document.createElement('div');
  category.className = 'result__triage-category';
  category.textContent = triage.category || 'unknown';

  const explanation = document.createElement('p');
  explanation.className = 'result__triage-text';
  explanation.textContent = triage.explanation || 'Review the execution evidence and rerun after narrowing the failed condition.';

  const nextAction = document.createElement('p');
  nextAction.className = 'result__triage-text result__triage-text--action';
  nextAction.textContent = triage.nextAction || 'Create a bug pack and rerun after the fix.';

  const actionRow = document.createElement('div');
  actionRow.className = 'result__triage-actions';
  (triage.actions || []).slice(0, 4).forEach(action => {
    actionRow.appendChild(createResultBadge(action.replace(/-/g, ' '), 'neutral'));
  });

  card.appendChild(title);
  card.appendChild(category);
  card.appendChild(explanation);
  card.appendChild(nextAction);
  card.appendChild(actionRow);
  return card;
}

function createResultBadge(label, tone) {
  const badge = document.createElement('span');
  badge.className = `result__badge result__badge--${tone}`;
  badge.textContent = label;
  return badge;
}

function createFindingCard(finding) {
  const card = document.createElement('article');
  card.className = 'result__finding';

  const header = document.createElement('div');
  header.className = 'result__finding-header';

  const rule = document.createElement('div');
  rule.className = 'result__finding-rule';
  rule.textContent = finding.title || 'finding';

  header.appendChild(rule);
  if (finding.wcag) {
    header.appendChild(createResultBadge(`WCAG ${finding.wcag}`, 'neutral'));
  }
  header.appendChild(createResultBadge(finding.severity || 'issue', badgeToneForSeverity(finding.severity)));

  const message = document.createElement('p');
  message.className = 'result__finding-message';
  message.textContent = finding.message || 'Issue detected.';

  const meta = document.createElement('div');
  meta.className = 'result__finding-meta';
  meta.appendChild(createFindingRow('Owner', finding.owner || 'QA'));
  meta.appendChild(createFindingRow('Category', finding.category || 'general'));

  if (finding.selector) {
    meta.appendChild(createFindingRow('Element', finding.selector));
  }

  if (finding.evidence) {
    meta.appendChild(createFindingRow('Evidence', finding.evidence));
  }

  meta.appendChild(createFindingRow('Fix', finding.fix || describeA11yFix(finding)));

  const controls = document.createElement('div');
  controls.className = 'result__finding-controls';

  // Each control is named for the finding it triages. Three unlabelled
  // selects sat on every finding card: a screen reader announced them only
  // as "combo box", with nothing to say which was severity, owner or status
  // — the exact fault this product reports as select-name on other people's
  // pages.
  const findingName = finding.title || finding.message || 'this finding';
  const severitySelect = buildFindingSelect(REPORT_SEVERITY_OPTIONS, finding.severity, nextSeverity => {
    updateFindingTriage(finding.id, { severity: nextSeverity });
  }, `Severity for ${findingName}`);
  const ownerSelect = buildFindingSelect(REPORT_OWNER_OPTIONS, finding.owner, nextOwner => {
    updateFindingTriage(finding.id, { owner: nextOwner });
  }, `Owner for ${findingName}`);
  const statusSelect = buildFindingSelect(['new', 'acknowledged', 'wont-fix', 'fixed'], finding.status || 'new', nextStatus => {
    updateFindingTriage(finding.id, { status: nextStatus });
  }, `Triage status for ${findingName}`);

  const notesInput = document.createElement('input');
  notesInput.type = 'text';
  notesInput.className = 'result__finding-notes';
  notesInput.placeholder = 'Add triage notes...';
  notesInput.setAttribute('aria-label', `Triage notes for ${findingName}`);
  notesInput.value = finding.notes || '';
  notesInput.addEventListener('change', () => {
    updateFindingTriage(finding.id, { notes: notesInput.value });
  });

  controls.appendChild(severitySelect);
  controls.appendChild(ownerSelect);
  controls.appendChild(statusSelect);

  const notesContainer = document.createElement('div');
  notesContainer.className = 'result__finding-notes-container';
  notesContainer.appendChild(notesInput);

  card.appendChild(header);
  card.appendChild(message);
  card.appendChild(meta);
  card.appendChild(controls);
  card.appendChild(notesContainer);
  return card;
}

function createFindingRow(label, value) {
  const row = document.createElement('div');
  row.className = 'result__finding-row';

  const key = document.createElement('span');
  key.className = 'result__finding-label';
  key.textContent = label;

  const text = document.createElement('span');
  text.className = 'result__finding-value';
  text.textContent = value;

  row.appendChild(key);
  row.appendChild(text);
  return row;
}

function describeA11yFix(finding) {
  switch (finding.ruleId || finding.title?.toLowerCase()) {
    case 'img-alt':
      return 'Add a meaningful alt attribute. If the image is decorative, use alt="" and presentational semantics when appropriate.';
    case 'img-alt-empty':
      return 'Confirm the image is decorative. If it conveys meaning, replace the empty alt text with a useful description.';
    case 'heading-order':
      return 'Use heading levels in sequence so screen-reader users can understand the page structure.';
    case 'label-input':
      return 'Associate the field with a visible <label>, or add aria-label/aria-labelledby if a visible label is not possible.';
    case 'color-contrast':
      return 'Increase foreground/background contrast until normal text reaches at least 4.5:1.';
    case 'landmark-main':
      return 'Wrap the main page content in a <main> element or add role="main" to the primary content container.';
    case 'link-text':
      return 'Replace generic link text with wording that clearly describes the destination or action.';
    case 'focus-visible':
      return 'Restore a visible focus outline or add a clear custom focus state.';
    case 'aria-valid-role':
      return 'Replace the invalid role with a valid WAI-ARIA role, or remove the role if it is unnecessary.';
    case 'aria-required-attr':
      return 'Add the ARIA attribute required by that role, such as aria-checked or aria-expanded.';
    case 'tab-index':
      return 'Remove positive tabindex values and rely on natural DOM order or tabindex="0" only when needed.';
    case 'lang-attr':
      return 'Add a valid lang attribute to the <html> element, such as lang="en".';
    default:
      return finding.fix || 'Update the failing UI or assertion and rerun the flow to confirm the fix.';
  }
}

function buildFindingSelect(options, selectedValue, onChange, accessibleName) {
  const select = document.createElement('select');
  select.className = 'result__finding-select';
  if (accessibleName) { select.setAttribute('aria-label', accessibleName); }
  select.innerHTML = options.map(option => `
    <option value="${option}" ${option === selectedValue ? 'selected' : ''}>${option}</option>
  `).join('');
  select.addEventListener('change', () => onChange(select.value));
  return select;
}


  return { renderResultDetails };
}
