/**
 * @fileoverview Replay module — time-travel replay overlay: DOM scrubber plus
 * console/network inspector panes showing state as-of each step
 * (v1.5 F1, extracted verbatim from sidepanel.js; zero behavior change).
 *
 * Owns its own scrubber state (timeline, index, playback) — the panel only
 * needs openReplay().
 */

import { SessionReplay } from '../../src/engine/session-replay.js';
import {
  createTimeline,
  frameAt,
  frameFromLog,
  stateAt,
  next as timelineNext,
  prev as timelinePrev,
  seekToFailure,
} from '../../src/engine/time-travel.js';

/**
 * @param {Object} ctx  Panel context.
 * @param {(text: string) => string} ctx.escapeHtml
 * @param {Object} ctx.elements  Replay overlay DOM refs.
 */
export function createReplayModule(ctx) {
  const { escapeHtml, elements } = ctx;
  const {
    overlay, frame: replayFrame, stepInfo, stepLabel,
    btnPrev, btnNext, btnPlay, btnFail, btnClose,
    consoleList, consoleCount, networkList, networkCount,
  } = elements;

  /** @type {ReturnType<typeof createTimeline>|null} */
  let replayTimeline = null;
  let currentReplayIndex = 0;
  let isPlayingReplay = false;
  let replayTimer = null;

  function openReplay(historyItem) {
    if (!historyItem || !historyItem.logs) { return; }

    // v1.4 F3: build a time-travel timeline from the run's logs. Snapshot logs
    // become pass frames; error logs become fail frames; per-step console and
    // network telemetry rides along for the inspector panes.
    const frames = [];
    historyItem.logs.forEach(l => {
      const f = frameFromLog(l, frames.length);
      if (f) { frames.push(f); }
    });

    if (!frames.some(f => f.domSnapshot)) {
      alert('No snapshots available for this session.');
      return;
    }

    replayTimeline = createTimeline(frames);
    currentReplayIndex = 0;
    if (btnFail) {
      (/** @type {HTMLElement} */ (btnFail)).hidden = replayTimeline.failureIndex === -1;
    }
    overlay.hidden = false;
    renderReplayStep();
  }

  function renderReplayStep() {
    if (!replayTimeline) { return; }
    const frame = frameAt(replayTimeline, currentReplayIndex);
    if (!frame) { return; }

    const marker = frame.status === 'fail' ? ' ✗' : '';
    stepInfo.textContent = `Step ${currentReplayIndex + 1} / ${replayTimeline.total}${marker}`;
    stepLabel.textContent = frame.label;
    // The label's base style is inline in the HTML, so restyle it inline too.
    stepLabel.style.background = frame.status === 'fail' ? 'rgba(180, 30, 30, 0.85)' : 'rgba(0, 0, 0, 0.7)';

    // A fail frame may have no snapshot of its own; show the DOM as of the last
    // captured state so the user sees the page at the failing moment.
    let domSnapshot = frame.domSnapshot;
    for (let i = currentReplayIndex; i >= 0 && !domSnapshot; i--) {
      domSnapshot = replayTimeline.frames[i].domSnapshot;
    }
    if (domSnapshot) {
      SessionReplay.replaySnapshot(domSnapshot, replayFrame);
    }

    renderReplayInspector();
  }

  /**
   * v1.4 F3: console + network panes showing cumulative state as-of the
   * scrubbed frame (stateAt aggregates every frame up to the current index).
   */
  function renderReplayInspector() {
    if (!consoleList || !networkList || !replayTimeline) { return; }
    const state = stateAt(replayTimeline, currentReplayIndex);

    if (consoleCount) { consoleCount.textContent = `(${state.console.length})`; }
    consoleList.innerHTML = state.console.length
      ? state.console.map(c => `
          <div class="replay-inspector__entry replay-inspector__entry--error">
            <span class="replay-inspector__tag">${escapeHtml(c.type || 'error')}</span>
            <span class="replay-inspector__text">${escapeHtml(c.message || '')}</span>
          </div>`).join('')
      : '<div class="replay-inspector__empty">No console errors up to this step.</div>';

    if (networkCount) { networkCount.textContent = `(${state.network.length})`; }
    networkList.innerHTML = state.network.length
      ? state.network.map(n => {
          const failed = typeof n.status === 'number' && n.status >= 400;
          return `
          <div class="replay-inspector__entry${failed ? ' replay-inspector__entry--error' : ''}">
            <span class="replay-inspector__tag">${escapeHtml(n.method || 'GET')} ${n.status ?? '—'}</span>
            <span class="replay-inspector__text" title="${escapeHtml(n.url || '')}">${escapeHtml(n.url || '')}</span>
          </div>`;
        }).join('')
      : '<div class="replay-inspector__empty">No requests up to this step.</div>';
  }

  btnPrev?.addEventListener('click', () => {
    if (!replayTimeline) { return; }
    currentReplayIndex = timelinePrev(replayTimeline, currentReplayIndex);
    renderReplayStep();
  });

  btnNext?.addEventListener('click', () => {
    if (!replayTimeline) { return; }
    currentReplayIndex = timelineNext(replayTimeline, currentReplayIndex);
    renderReplayStep();
  });

  btnFail?.addEventListener('click', () => {
    if (!replayTimeline) { return; }
    currentReplayIndex = seekToFailure(replayTimeline);
    renderReplayStep();
  });

  btnPlay?.addEventListener('click', () => {
    isPlayingReplay = !isPlayingReplay;
    btnPlay.textContent = isPlayingReplay ? 'Stop' : 'Play';

    if (isPlayingReplay) {
      const playNext = () => {
        if (replayTimeline && currentReplayIndex < replayTimeline.total - 1) {
          currentReplayIndex = timelineNext(replayTimeline, currentReplayIndex);
          renderReplayStep();
          replayTimer = setTimeout(playNext, 2000);
        } else {
          isPlayingReplay = false;
          btnPlay.textContent = 'Play';
        }
      };
      playNext();
    } else {
      clearTimeout(replayTimer);
    }
  });

  btnClose?.addEventListener('click', () => {
    overlay.hidden = true;
    clearTimeout(replayTimer);
    isPlayingReplay = false;
    btnPlay.textContent = 'Play';
  });

  return { openReplay };
}
