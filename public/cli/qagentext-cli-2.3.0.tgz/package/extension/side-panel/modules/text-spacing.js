/**
 * @fileoverview The text-spacing editor (v2.3): WCAG 1.4.12 by hand.
 *
 * Four values a tester can set — line height, letter, word and paragraph
 * spacing — applied live to the page, with the same measurement the scanner
 * rule makes reported back: what now clips, what now overlaps. A preset puts
 * the values at the 1.4.12 minimums. The values stay on across pages until
 * switched off, and the keyboard shortcut toggles them without the panel.
 *
 * Decisions live in src/engine/text-spacing.js; this module keeps state,
 * renders it, and talks to the page through the hooks it is given.
 */

import { MSG, TEXT_SPACING_KEY } from '../../src/shared/constants.js';
import { SPACING_LIMITS, WCAG_TEXT_SPACING, normalizeSpacing, describeImpact } from '../../src/engine/text-spacing.js';

const PUSH_DELAY_MS = 150;

/**
 * @param {Object} ctx
 * @param {HTMLElement} ctx.section   Where the editor renders; hidden until opened.
 * @param {HTMLButtonElement} ctx.button  The toolbar toggle for the editor.
 * @param {(message: Object) => Promise<any>} ctx.sendToTab  Sends to the target page's content script.
 * @param {(text: any) => string} ctx.escapeHtml
 * @param {{ get: Function, set: Function }} [ctx.storage]
 * @param {(listener: (changes: Object) => void) => void} [ctx.onStorageChanged]  Subscribes to storage changes.
 */
export function createTextSpacingModule(ctx) {
  const store = ctx.storage || chrome.storage.local;
  const esc = ctx.escapeHtml;
  const state = { enabled: false, settings: { ...WCAG_TEXT_SPACING }, impact: null, error: '', note: '', rendered: false };
  let pushTimer = null;
  let pushing = null;

  const ready = store.get(TEXT_SPACING_KEY).then(data => {
    const stored = data && data[TEXT_SPACING_KEY];
    if (stored && typeof stored === 'object') {
      state.enabled = Boolean(stored.enabled);
      state.settings = normalizeSpacing(stored.settings);
    }
  }).catch(() => {});

  const $ = id => /** @type {HTMLInputElement} */ (ctx.section.querySelector(`#${id}`));
  const save = () => store.set({ [TEXT_SPACING_KEY]: { enabled: state.enabled, settings: state.settings } }).catch(() => {});

  // --- Rendering ---------------------------------------------------------------

  function render() {
    state.rendered = true;
    ctx.section.innerHTML = `
      <div class="text-spacing__header"><strong>Text spacing</strong><span>WCAG 1.4.12</span></div>
      ${Object.entries(SPACING_LIMITS).map(([key, limit]) => `
        <div class="text-spacing__row">
          <label for="ts-${key}">${esc(limit.label)}</label>
          <input type="range" id="ts-${key}" data-key="${key}" min="${limit.min}" max="${limit.max}" step="${limit.step}" value="${state.settings[key]}">
          <input type="number" id="ts-${key}-num" data-key="${key}" class="text-spacing__num" min="${limit.min}" max="${limit.max}" step="${limit.step}" value="${state.settings[key]}" aria-label="${esc(limit.label)} value">
          <span class="text-spacing__unit">${esc(limit.unit)}</span>
        </div>`).join('')}
      <div class="text-spacing__actions">
        <label class="text-spacing__toggle"><input type="checkbox" id="ts-enabled" ${state.enabled ? 'checked' : ''}>Apply to page</label>
        <button type="button" class="btn btn--secondary btn--small" id="ts-preset">WCAG minimums</button>
        <button type="button" class="btn btn--secondary btn--small" id="ts-reset">Reset</button>
      </div>
      <output id="ts-status" class="text-spacing__status" role="status" aria-live="polite" aria-atomic="true"></output>
      <ul id="ts-impact" class="text-spacing__impact"></ul>
      <p class="text-spacing__hint">Alt+Shift+S toggles these values on any page (change the key at chrome://extensions/shortcuts). They stay on across pages until you turn them off.</p>`;
    bind();
    renderStatus();
  }

  function renderStatus() {
    const status = $('ts-status');
    const list = $('ts-impact');
    if (!status || !list) { return; }
    status.classList.toggle('text-spacing__status--error', Boolean(state.error));
    if (state.error) {
      status.textContent = state.error;
      list.innerHTML = '';
      return;
    }
    if (!state.enabled) {
      status.textContent = state.note || 'Off. The page shows its own spacing.';
      list.innerHTML = '';
      return;
    }
    status.textContent = `${state.note || 'Applied.'} ${describeImpact(state.impact)}`.trim();
    const impact = state.impact || { clipped: [], overlaps: [] };
    list.innerHTML = [
      ...impact.clipped.slice(0, 6).map(c => `<li>${esc(c.selector)} hides ${esc(c.y > c.x ? `${c.y}px below its bottom edge` : `${c.x}px past its right edge`)}</li>`),
      ...impact.overlaps.slice(0, 6).map(o => `<li>${esc(o.a)} overlaps ${esc(o.b)} (${esc(o.width)}×${esc(o.height)}px)</li>`),
    ].join('');
  }

  function renderValues() {
    for (const key of Object.keys(SPACING_LIMITS)) {
      const range = $(`ts-${key}`);
      const number = $(`ts-${key}-num`);
      if (range) { range.value = String(state.settings[key]); }
      if (number) { number.value = String(state.settings[key]); }
    }
    const enabled = $('ts-enabled');
    if (enabled) { enabled.checked = state.enabled; }
  }

  // --- Events -----------------------------------------------------------------

  function bind() {
    for (const input of ctx.section.querySelectorAll('input[data-key]')) {
      input.addEventListener('input', event => {
        const el = /** @type {HTMLInputElement} */ (event.target);
        const key = el.dataset.key;
        const next = normalizeSpacing({ ...state.settings, [key]: Number(el.value) });
        state.settings = next;
        const twin = el.type === 'range' ? $(`ts-${key}-num`) : $(`ts-${key}`);
        if (twin) { twin.value = String(next[key]); }
        state.note = '';
        save();
        if (state.enabled) { schedulePush(); }
      });
    }
    $('ts-enabled')?.addEventListener('change', event => {
      state.enabled = /** @type {HTMLInputElement} */ (event.target).checked;
      state.note = '';
      save();
      push();
    });
    $('ts-preset')?.addEventListener('click', () => {
      state.settings = { ...WCAG_TEXT_SPACING };
      state.note = '';
      renderValues();
      save();
      if (state.enabled) { push(); } else { renderStatus(); }
    });
    $('ts-reset')?.addEventListener('click', () => {
      state.settings = { ...WCAG_TEXT_SPACING };
      state.enabled = false;
      state.note = '';
      renderValues();
      save();
      push();
    });
  }

  function schedulePush() {
    clearTimeout(pushTimer);
    pushTimer = setTimeout(() => { push(); }, PUSH_DELAY_MS);
  }

  /** Send the current state to the page and show what it did. One at a time; the latest wins. */
  function push() {
    clearTimeout(pushTimer);
    if (pushing) { pushing.then(push, push); pushing = null; return; }
    const message = { type: MSG.TEXT_SPACING, settings: state.enabled ? state.settings : null };
    pushing = ctx.sendToTab(message).then(response => {
      if (!response || response.success === false) { throw new Error((response && response.error) || 'The page did not answer.'); }
      state.impact = response.impact || null;
      state.error = '';
    }).catch(error => {
      state.error = `Cannot apply on this page: ${/establish connection|Receiving end/i.test(error.message) ? 'open a normal web page, then try again.' : error.message}`;
    }).then(() => {
      pushing = null;
      renderStatus();
    });
    return pushing;
  }

  // The shortcut (service worker) and other panels write the same key.
  if (ctx.onStorageChanged) {
    ctx.onStorageChanged(changes => {
      const change = changes && changes[TEXT_SPACING_KEY];
      if (!change || !change.newValue) { return; }
      const next = change.newValue;
      const same = next.enabled === state.enabled && JSON.stringify(normalizeSpacing(next.settings)) === JSON.stringify(state.settings);
      if (same) { return; }
      state.enabled = Boolean(next.enabled);
      state.settings = normalizeSpacing(next.settings);
      state.note = state.enabled ? 'Switched on by the shortcut.' : 'Switched off by the shortcut.';
      state.impact = null;
      if (state.rendered) { renderValues(); renderStatus(); }
    });
  }

  // --- Public -----------------------------------------------------------------

  async function toggle() {
    await ready;
    const open = ctx.section.hidden;
    ctx.section.hidden = !open;
    ctx.button.setAttribute('aria-pressed', String(open));
    if (open) {
      if (!state.rendered) { render(); }
      if (state.enabled) { push(); } // the page may have changed since
    }
  }

  return { toggle, push, getState: () => ({ ...state }) };
}
