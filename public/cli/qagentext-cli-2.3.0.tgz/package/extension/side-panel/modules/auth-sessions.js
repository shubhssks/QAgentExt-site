/**
 * @fileoverview Auth-sessions module — capture/restore/delete authenticated
 * session snapshots in the Profiles tab (v1.5 F1, extracted verbatim from
 * sidepanel.js; zero behavior change).
 */

import { MSG } from '../../src/shared/constants.js';
import { STORAGE_KEY_SESSIONS, checkSessionHealth } from '../../src/engine/session-auth.js';

/**
 * @param {Object} ctx  Panel context.
 * @param {(filter?: string) => void} ctx.renderLibrary
 * @param {(entry: Object) => void} ctx.appendLog
 * @param {() => Promise<Object|undefined>} ctx.getTargetTab
 * @param {{ librarySearch: HTMLInputElement }} ctx.elements
 */
export function createAuthSessionsModule(ctx) {
  const { renderLibrary, appendLog, getTargetTab, elements } = ctx;

  function renderAuthSessions(container) {
    const wrap = document.createElement('div');
    wrap.className = 'auth-sessions';
    wrap.innerHTML = `
      <div class="auth-sessions__header">
        <strong>🔐 Auth Sessions</strong>
        <button class="btn btn--secondary btn--small" data-action="capture-auth" type="button"
          title="Log in manually once, then capture the session to reuse across runs">+ Capture current session</button>
      </div>
      <div class="auth-sessions__list" data-role="auth-list"><small>Loading…</small></div>
    `;
    container.appendChild(wrap);

    wrap.querySelector('[data-action="capture-auth"]')?.addEventListener('click', async () => {
      const name = prompt('Name this auth session (e.g. "Staging admin"):', 'Logged-in session');
      if (!name) { return; }
      chrome.runtime.sendMessage({ type: MSG.CREATE_SESSION_SNAPSHOT, name }, (response) => {
        if (response && response.success) {
          appendLog({ type: 'success', timestamp: new Date().toISOString(), message: `Auth session "${name}" captured. Restore it any time from the Profiles tab.` });
          renderLibrary(elements.librarySearch.value.trim());
        } else {
          appendLog({ type: 'error', timestamp: new Date().toISOString(), message: `Session capture failed: ${response?.error || 'no response'}` });
        }
      });
    });

    const list = wrap.querySelector('[data-role="auth-list"]');
    chrome.storage.local.get(STORAGE_KEY_SESSIONS, (data) => {
      const snapshots = data[STORAGE_KEY_SESSIONS] || [];
      list.innerHTML = '';
      if (!snapshots.length) {
        list.innerHTML = '<small>No captured sessions. Log in manually on a page, then capture it here — future runs can skip the login.</small>';
        return;
      }
      snapshots.forEach((snap, index) => {
        const health = checkSessionHealth(snap);
        const row = document.createElement('div');
        row.className = 'auth-sessions__item';

        const main = document.createElement('div');
        main.className = 'auth-sessions__main';
        const title = document.createElement('strong');
        title.textContent = snap.name || `Session ${index + 1}`;
        const meta = document.createElement('small');
        meta.textContent = `${snap.domain || 'unknown domain'} · ${snap.capturedAt ? new Date(snap.capturedAt).toLocaleString() : ''} · ${health.valid ? 'healthy' : `⚠ ${health.reason || 'may be stale'}`}`;
        main.appendChild(title);
        main.appendChild(meta);

        const actions = document.createElement('div');
        actions.className = 'auth-sessions__actions';

        const restoreBtn = document.createElement('button');
        restoreBtn.className = 'btn btn--secondary btn--small';
        restoreBtn.type = 'button';
        restoreBtn.textContent = 'Restore';
        restoreBtn.title = 'Load this session into the active tab and reload';
        restoreBtn.addEventListener('click', async () => {
          restoreBtn.disabled = true;
          chrome.runtime.sendMessage({ type: MSG.LOAD_SESSION_SNAPSHOT, snapshot: snap }, async (response) => {
            if (response && response.success) {
              const tab = await getTargetTab();
              if (tab?.id) { chrome.tabs.reload(tab.id); }
              appendLog({ type: 'success', timestamp: new Date().toISOString(), message: `Auth session "${snap.name}" restored — page reloading with saved login state.` });
            } else {
              appendLog({ type: 'error', timestamp: new Date().toISOString(), message: `Restore failed: ${response?.error || 'no response'}` });
            }
            restoreBtn.disabled = false;
          });
        });

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn--icon';
        deleteBtn.type = 'button';
        deleteBtn.textContent = '✕';
        deleteBtn.title = 'Delete this session';
        deleteBtn.addEventListener('click', async () => {
          const next = snapshots.filter((_, i) => i !== index);
          await chrome.storage.local.set({ [STORAGE_KEY_SESSIONS]: next });
          renderLibrary(elements.librarySearch.value.trim());
        });

        actions.appendChild(restoreBtn);
        actions.appendChild(deleteBtn);
        row.appendChild(main);
        row.appendChild(actions);
        list.appendChild(row);
      });
    });
  }

  return { renderAuthSessions };
}
