/** @fileoverview Regression progress, run history, and execution settings. */
import { RUN_PLAN_CONFIG, failedRunPlanIds, failedRunPlanCaseIds, runPlanJUnitCases } from '../../src/engine/run-plan.js';
import { buildJUnitXml } from '../../src/engine/junit.js';
import { normalizeRunPlan } from '../../src/engine/run-plan.js';
import { caseEvidence } from '../../src/engine/run-evidence.js';

/**
 * Create the Runs library view using the panel's shared controls and storage.
 * @param {Object} ctx
 * @returns {Object}
 */
export function createRunPlansModule(ctx) {
  let current = null;
  let selected = null;
  let settings = { retries: 0, maxFailures: 0, failOnFlaky: true };
  let revision = 0;
  let matrix = false;
  const selectedEnvironmentIds = new Set();
  const settingsReady = chrome.storage.local.get(RUN_PLAN_CONFIG.SETTINGS_KEY).then(data => {
    settings = { ...settings, ...data[RUN_PLAN_CONFIG.SETTINGS_KEY] };
  }).catch(() => {});

  function receive(run) {
    if (!run) { return; }
    current = run;
    selected = run;
    if (ctx.isVisible()) { render(); }
  }

  async function render() {
    const renderRevision = ++revision;
    await settingsReady;
    const data = await chrome.storage.local.get(RUN_PLAN_CONFIG.HISTORY_KEY);
    if (!ctx.isVisible() || renderRevision !== revision) { return; }
    const host = ctx.container;
    const history = data[RUN_PLAN_CONFIG.HISTORY_KEY] || [];
    selected ||= current || history[0] || null;
    const esc = ctx.escapeHtml;
    const profiles = ctx.getProfiles();
    host.innerHTML = `
      <section class="run-plans" aria-label="Regression runs">
        <div class="run-plans__toolbar">
          <h3>Regression runs</h3>
          <button type="button" class="btn btn--primary btn--small" id="run-plan-library">Run library</button>
          <button type="button" class="btn btn--secondary btn--small" id="run-plan-export">Export plan</button>
        </div>
        <fieldset class="run-plans__settings">
          <legend>Run settings</legend>
          <label>Retries<select id="run-plan-retries"><option value="0">None</option><option value="1">1 retry</option><option value="2">2 retries</option></select></label>
          <label>Stop after failures<input id="run-plan-limit" type="number" min="0" max="200" value="${Number(settings.maxFailures) || 0}"></label>
          <label class="run-plans__toggle"><input id="run-plan-flaky" type="checkbox" ${settings.failOnFlaky ? 'checked' : ''}>Fail gate on flaky tests</label>
        </fieldset>
        <fieldset class="run-plans__environments">
          <legend>Environments</legend>
          <label><input type="checkbox" id="run-plan-matrix" ${matrix ? 'checked' : ''} ${ctx.isBusy() ? 'disabled' : ''}>Run across environments</label>
          <div id="run-plan-environments" ${matrix ? '' : 'hidden'}>
            ${profiles.length ? profiles.map(profile => `<label><input type="checkbox" value="${esc(profile.id)}" ${selectedEnvironmentIds.has(profile.id) ? 'checked' : ''} ${ctx.isBusy() ? 'disabled' : ''}><span>${esc(profile.name)}<small>${esc(profile.baseUrl || 'No base URL')}</small></span></label>`).join('') : '<p>No environment profiles.</p>'}
          </div>
        </fieldset>
        <p id="run-plan-error" role="alert"></p>
        <div id="run-plan-detail"></div>
        <label class="run-plans__history">Recent runs<select id="run-plan-history"><option value="">Select a run</option>${history.map(run => `<option value="${esc(run.id)}">${esc(run.name)} (${esc(run.state)})</option>`).join('')}</select></label>
      </section>`;
    ctx.empty.style.display = 'none';
    host.querySelector('#run-plan-retries').value = String(settings.retries);
    host.querySelector('#run-plan-library').disabled = ctx.isBusy() || !ctx.getLibrary().length || (matrix && !selectedEnvironmentIds.size);
    host.querySelector('#run-plan-library').addEventListener('click', () => ctx.runSuite({ name: 'Library regression', testIds: ctx.getLibrary().map(test => test.id), environmentIds: matrix ? [...selectedEnvironmentIds] : null }));
    host.querySelector('#run-plan-export').disabled = !ctx.getLibrary().length || (matrix && !selectedEnvironmentIds.size);
    host.querySelector('#run-plan-export').addEventListener('click', () => {
      try {
        const environments = matrix ? [...selectedEnvironmentIds].map(id => profiles.find(profile => profile.id === id)) : undefined;
        const plan = normalizeRunPlan({ name: 'Library regression', tests: ctx.getLibrary().map(test => ctx.prepareTest(test, matrix)), settings, ...(matrix ? { environments } : {}) });
        ctx.downloadFile('qagent-plan.json', JSON.stringify(plan, null, 2), 'application/json');
      } catch (error) { host.querySelector('#run-plan-error').textContent = error.message; }
    });
    host.querySelector('.run-plans__environments').addEventListener('change', event => {
      const target = event.target;
      if (target.id === 'run-plan-matrix') { matrix = target.checked; }
      else if (target.checked) { selectedEnvironmentIds.add(target.value); }
      else { selectedEnvironmentIds.delete(target.value); }
      render();
    });
    host.querySelector('.run-plans__settings').addEventListener('change', async () => {
      const limit = host.querySelector('#run-plan-limit');
      if (!limit.reportValidity()) { return; }
      settings = {
        retries: Number(host.querySelector('#run-plan-retries').value),
        maxFailures: Number(limit.value),
        failOnFlaky: host.querySelector('#run-plan-flaky').checked,
      };
      await chrome.storage.local.set({ [RUN_PLAN_CONFIG.SETTINGS_KEY]: settings });
    });
    host.querySelector('#run-plan-history').addEventListener('change', event => {
      selected = history.find(run => run.id === event.target.value) || current;
      renderDetail();
    });
    renderDetail();
  }

  function renderDetail() {
    const host = ctx.container.querySelector('#run-plan-detail');
    if (!host) { return; }
    if (!selected) { host.textContent = 'No regression runs yet.'; return; }
    const run = selected;
    const summary = run.summary;
    const esc = ctx.escapeHtml;
    host.innerHTML = `
      <div class="run-plans__summary" role="status" aria-live="polite">
        <h3>${esc(run.name)}</h3>
        <p>${esc(run.state)}${run.state === 'running' ? '' : ` | Quality gate: ${esc(summary.gate).toUpperCase()}`}</p>
        <progress max="${summary.total || 1}" value="${summary.completed}" aria-label="Completed regression tests"></progress>
        <p>${summary.passed} passed | ${summary.failed} failed | ${summary.flaky} flaky | ${summary.skipped} skipped</p>
        ${run.reason ? `<p>${esc(run.reason)}</p>` : ''}
        ${run.storageWarning ? `<p>${esc(run.storageWarning)}</p>` : ''}
        ${run.diagnosticsTruncated ? '<p>Some diagnostics were shortened to fit run history. All test outcomes and attempt counts are retained.</p>' : ''}
        <p class="run-plans__target">${esc(run.url)}</p>
      </div>
      <div class="run-plans__toolbar">
        <button class="btn btn--secondary btn--small" type="button" id="run-plan-rerun">Rerun failed</button>
        <button class="btn btn--secondary btn--small" type="button" id="run-plan-junit">Export JUnit</button>
        <button class="btn btn--secondary btn--small" type="button" id="run-plan-json">Export JSON</button>
      </div>
      <ol class="run-plans__cases">${run.cases.map(item => `
        <li class="run-plans__case" data-status="${esc(item.status)}">
          <div><strong>${esc(item.name)}</strong><span>${esc(item.status)} | ${item.attempts.length} attempts</span></div>
          ${item.reason ? `<p>${esc(item.reason)}</p>` : ''}
          ${renderEvidence(item, esc)}
          ${item.attempts.length ? `<details><summary>Attempts</summary><ol>${item.attempts.map(attempt => `<li>${esc(attempt.status)} (${attempt.durationMs} ms): ${esc(attempt.reason)}</li>`).join('')}</ol></details>` : ''}
        </li>`).join('')}</ol>`;
    const rerun = host.querySelector('#run-plan-rerun');
    const failedIds = failedRunPlanIds(run);
    rerun.disabled = ctx.isBusy() || !failedIds.length;
    rerun.addEventListener('click', () => ctx.runSuite({
      name: `Rerun: ${run.name}`, testIds: failedIds,
      caseIds: failedRunPlanCaseIds(run), environmentIds: run.environments?.map(environment => environment.id) || null,
    }));
    host.querySelector('#run-plan-junit').disabled = run.state === 'running';
    host.querySelector('#run-plan-junit').addEventListener('click', () => {
      ctx.downloadFile('qagent-regression.xml', buildJUnitXml({ cases: runPlanJUnitCases(run), suiteName: run.name }), 'application/xml');
    });
    host.querySelector('#run-plan-json').addEventListener('click', () => {
      ctx.downloadFile('qagent-regression.json', JSON.stringify(run, null, 2), 'application/json');
    });
  }

  return { render, receive, getSettings: () => ({ ...settings }), getEnvironmentIds: () => matrix ? [...selectedEnvironmentIds] : null, settingsReady };
}

function renderEvidence(item, esc) {
  const evidence = caseEvidence(item);
  if (!evidence || (!evidence.findingsTotal && !evidence.category)) { return ''; }
  return `<details class="run-plans__evidence"><summary>Failure details${evidence.findingsTotal ? ` (${evidence.findings.length}/${evidence.findingsTotal} findings retained)` : ''}</summary>
    <p>${esc(evidence.headline)}</p>
    ${evidence.failedStepIndex !== undefined ? `<p>Failed step ${evidence.failedStepIndex + 1}: ${esc(evidence.step.action)} ${esc(evidence.step.check)}</p>` : ''}
    <p>${esc(evidence.nextAction)}</p>
    <ul>${evidence.findings.map(finding => `<li><strong>${esc(finding.severity)}: ${esc(finding.title)}</strong><p>${esc(finding.message)}</p>${finding.selector ? `<code>${esc(finding.selector)}</code>` : ''}${finding.fix ? `<p>${esc(finding.fix)}</p>` : ''}</li>`).join('')}</ul>
    ${evidence.console.length ? `<h4>Console</h4><ul>${evidence.console.map(entry => `<li>${esc(entry.message)}</li>`).join('')}</ul>` : ''}
    ${evidence.network.length ? `<h4>Requests</h4><ul>${evidence.network.map(entry => `<li>${esc(entry.method)} ${esc(entry.url)}: ${esc(entry.status)}</li>`).join('')}</ul>` : ''}
  </details>`;
}
