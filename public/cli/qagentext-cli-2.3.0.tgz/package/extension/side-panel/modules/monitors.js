/**
 * @fileoverview Monitors module — scheduled-monitor tab UI + due-run handling
 * (v1.5 F1, extracted verbatim from sidepanel.js; zero behavior change).
 *
 * The panel orchestrator owns shared state (library, activeSuite, run flow)
 * and passes access through the context object; this module owns everything
 * monitor-specific: the Monitors tab, monitor items, due-run dispatch, the
 * notification fallback, and the webhook POST.
 */

import { MSG } from '../../src/shared/constants.js';
import { buildWebhookRequest, testsInFolder, describeNextRun, appendMonitorOutcome, summarizeMonitorHistory } from '../../src/engine/schedule-engine.js';

/** Storage key for per-schedule run outcomes (v1.5 P4). */
const MONITOR_HISTORY_KEY = 'qagent_monitor_history';

/**
 * @param {Object} ctx  Panel context.
 * @param {() => Array<Object>} ctx.getLibrary        Current library array.
 * @param {() => string} ctx.getActiveLibraryTab      Active library tab id.
 * @param {() => boolean} ctx.isRunActive             True when a run/suite is in flight.
 * @param {() => Object|null} ctx.getActiveSuite      Current suite state (mutable).
 * @param {(suite: Object) => void} ctx.runSuite      Start a suite run.
 * @param {(filter?: string) => void} ctx.renderLibrary
 * @param {(entry: Object) => void} ctx.appendLog
 * @param {(text: string) => string} ctx.escapeHtml
 * @param {{ libraryContainer: HTMLElement, libraryEmpty: HTMLElement, librarySearch: HTMLInputElement }} ctx.elements
 */
export function createMonitorsModule(ctx) {
  const { getLibrary, getActiveLibraryTab, isRunActive, getActiveSuite, runSuite, renderLibrary, appendLog, escapeHtml, elements } = ctx;

  /**
   * A monitor fired: run its folder unattended when the panel is idle, else
   * fall back to a notification so the user can run it manually.
   * @param {Object} schedule
   */
  function handleScheduleDue(schedule) {
    const folder = schedule && schedule.folderId ? schedule.folderId : '';
    const tests = testsInFolder(getLibrary(), folder);

    if (isRunActive()) {
      appendLog({ type: 'warn', timestamp: new Date().toISOString(), message: `Scheduled monitor for "${folder}" is due, but a run is already in progress. Skipping this cycle.` });
      notifyScheduleDue(folder);
      return;
    }
    if (tests.length === 0) {
      appendLog({ type: 'warn', timestamp: new Date().toISOString(), message: `Scheduled monitor for "${folder}" fired, but no library tests are in that folder.` });
      return;
    }

    appendLog({ type: 'info', timestamp: new Date().toISOString(), message: `[Monitor] Running scheduled folder "${folder}" (${tests.length} tests).` });
    runSuite({ name: `Monitor: ${folder}`, testIds: tests.map(t => t.id) });
    const activeSuite = getActiveSuite();
    if (activeSuite) {
      activeSuite.schedule = schedule;
    }
  }

  function notifyScheduleDue(folder) {
    try {
      if (chrome.notifications && chrome.notifications.create) {
        chrome.notifications.create({
          type: 'basic',
          iconUrl: '../assets/icons/icon-48.png',
          title: 'QAgentExt scheduled check',
          message: `A scheduled monitor for "${folder}" is due to run.`,
        });
      }
    } catch { /* notifications are best-effort */ }
  }

  /**
   * POST the scheduled-run outcome to the user-configured webhook. Failures
   * are logged, never fatal.
   * @param {Object} schedule
   * @param {{passed:number, failed:number, total:number}} results
   */
  async function postScheduleWebhook(schedule, results) {
    const request = buildWebhookRequest(schedule, results);
    if (!request) { return; }
    try {
      const response = await fetch(request.url, {
        method: request.method,
        headers: request.headers,
        body: request.body,
      });
      if (response.ok) {
        appendLog({ type: 'success', timestamp: new Date().toISOString(), message: `[Monitor] Webhook notified (${results.passed}/${results.total} passed).` });
      } else {
        appendLog({ type: 'warn', timestamp: new Date().toISOString(), message: `[Monitor] Webhook responded ${response.status}.` });
      }
    } catch (err) {
      appendLog({ type: 'warn', timestamp: new Date().toISOString(), message: `[Monitor] Webhook POST failed: ${err.message}` });
    }
  }

  /**
   * v1.5 P4: persist a finished scheduled-run outcome to the monitor's history
   * (capped, per schedule). Called by the panel when a monitor suite finishes.
   * @param {Object} schedule
   * @param {{passed:number, failed:number, total:number}} results
   */
  function recordMonitorOutcome(schedule, results) {
    if (!schedule || !schedule.id) { return; }
    chrome.storage.local.get([MONITOR_HISTORY_KEY], (data) => {
      const next = appendMonitorOutcome(data[MONITOR_HISTORY_KEY] || {}, schedule.id, results);
      chrome.storage.local.set({ [MONITOR_HISTORY_KEY]: next });
    });
  }

  /** Distinct non-empty folder names currently used in the library. */
  function libraryFolders() {
    return Array.from(new Set(
      getLibrary().map(t => String(t.folder || '').trim()).filter(Boolean)
    )).sort();
  }

  function renderMonitorsTab() {
    const { libraryContainer, libraryEmpty, librarySearch } = elements;
    const form = document.createElement('div');
    form.className = 'monitor-form';
    const folders = libraryFolders();
    form.innerHTML = `
      <div class="monitor-form__row">
        <input type="text" id="monitor-folder" class="library__search-input" list="monitor-folder-options"
          placeholder="Library folder (e.g. smoke)" aria-label="Folder to monitor">
        <datalist id="monitor-folder-options">
          ${folders.map(f => `<option value="${escapeHtml(f)}"></option>`).join('')}
        </datalist>
        <input type="number" id="monitor-interval" class="library__search-input monitor-form__interval" min="15"
          step="15" value="60" aria-label="Interval in minutes" title="Interval in minutes (min 15)">
      </div>
      <div class="monitor-form__row">
        <input type="url" id="monitor-webhook" class="library__search-input"
          placeholder="Webhook URL (optional, e.g. Slack)" aria-label="Webhook URL">
        <button id="btn-monitor-add" class="btn btn--primary btn--small">+ Monitor</button>
      </div>
      <div class="monitor-form__row">
        <label class="monitor-form__bg" title="Off by default. When on, this monitor opens the URL in a background tab on schedule even if the panel is closed, then closes it.">
          <input type="checkbox" id="monitor-background"> Run in background when panel is closed
        </label>
        <input type="url" id="monitor-target" class="library__search-input"
          placeholder="URL to monitor (required for background runs)" aria-label="URL to monitor">
      </div>
      <p class="monitor-form__hint">Monitors run while the side panel is open; otherwise you get a notification.
        Enable "run in background" to have a monitor open its URL in an inactive tab on schedule and close it when done (off by default).
        Results post to your webhook — no other network calls are made.</p>`;
    libraryContainer.appendChild(form);

    form.querySelector('#btn-monitor-add')?.addEventListener('click', () => {
      const folderId = (/** @type {HTMLInputElement} */ (form.querySelector('#monitor-folder'))).value.trim();
      const intervalMinutes = Number((/** @type {HTMLInputElement} */ (form.querySelector('#monitor-interval'))).value);
      const webhookUrl = (/** @type {HTMLInputElement} */ (form.querySelector('#monitor-webhook'))).value.trim();
      const backgroundRun = (/** @type {HTMLInputElement} */ (form.querySelector('#monitor-background'))).checked;
      const targetUrl = (/** @type {HTMLInputElement} */ (form.querySelector('#monitor-target'))).value.trim();

      chrome.runtime.sendMessage({
        type: MSG.SCHEDULE_SAVE,
        schedule: { folderId, intervalMinutes, webhookUrl, targetUrl, backgroundRun, enabled: true },
      }, (response) => {
        if (response && response.success) {
          appendLog({ type: 'success', timestamp: new Date().toISOString(), message: `Monitor for "${folderId}" saved — runs every ${intervalMinutes} min.` });
          renderLibrary(librarySearch.value.trim());
        } else {
          const errors = (response && response.errors) ? response.errors.join(' ') : 'no response from background';
          appendLog({ type: 'error', timestamp: new Date().toISOString(), message: `Monitor not saved: ${errors}` });
        }
      });
    });

    const listHost = document.createElement('div');
    listHost.className = 'monitor-list';
    libraryContainer.appendChild(listHost);

    chrome.runtime.sendMessage({ type: MSG.SCHEDULE_LIST }, (response) => {
      if (getActiveLibraryTab() !== 'monitors') { return; }
      const schedules = (response && response.schedules) || [];
      libraryEmpty.style.display = schedules.length ? 'none' : 'block';
      // v1.5 P4: fetch per-schedule run history (live read) for the sparklines.
      chrome.storage.local.get([MONITOR_HISTORY_KEY], (data) => {
        const historyMap = data[MONITOR_HISTORY_KEY] || {};
        schedules.forEach(schedule => listHost.appendChild(renderMonitorItem(schedule, historyMap[schedule.id] || [])));
      });
    });
  }

  function renderMonitorItem(schedule, outcomes = []) {
    const { librarySearch } = elements;
    const testCount = testsInFolder(getLibrary(), schedule.folderId).length;
    // v1.5 P4: recent-run sparkline + last-run summary.
    const summary = summarizeMonitorHistory(outcomes);
    const spark = outcomes.length
      ? `<span class="monitor-item__sparkline" title="${summary.count} recent run(s), ${summary.failCount} failed">` +
        outcomes.map(o => `<span class="monitor-item__spark monitor-item__spark--${o.ok ? 'pass' : 'fail'}"></span>`).join('') +
        `</span>`
      : '';
    const lastRun = summary.lastRanAt
      ? `<small class="monitor-item__last">last: ${summary.lastOk ? '✓ passed' : '✗ failed'} · ${new Date(summary.lastRanAt).toLocaleString()}</small>`
      : '';
    const el = document.createElement('div');
    el.className = 'library-item';
    el.innerHTML = `
      <div class="library-item__main">
        <strong>${escapeHtml(schedule.folderId)}</strong>
        <small>every ${schedule.intervalMinutes} min &middot; ${describeNextRun(schedule)} &middot; ${testCount} test(s)</small>
        ${schedule.webhookUrl ? `<small class="monitor-item__webhook" title="${escapeHtml(schedule.webhookUrl)}">webhook configured</small>` : ''}
        ${lastRun}
        ${spark}
      </div>
      <div class="library-item__actions">
        <button class="btn--icon" title="Run now" data-action="run-now">&#9654;&#65039;</button>
        <button class="btn--icon" title="${schedule.enabled ? 'Pause monitor' : 'Resume monitor'}" data-action="toggle">${schedule.enabled ? '&#9208;&#65039;' : '&#9655;'}</button>
        <button class="btn--icon" title="Delete monitor" data-action="delete">&#128465;&#65039;</button>
      </div>`;

    el.querySelector('[data-action="run-now"]')?.addEventListener('click', () => {
      handleScheduleDue(schedule);
    });

    el.querySelector('[data-action="toggle"]')?.addEventListener('click', () => {
      chrome.runtime.sendMessage({
        type: MSG.SCHEDULE_SAVE,
        schedule: { ...schedule, enabled: !schedule.enabled },
      }, () => renderLibrary(librarySearch.value.trim()));
    });

    el.querySelector('[data-action="delete"]')?.addEventListener('click', () => {
      if (!confirm(`Delete the monitor for "${schedule.folderId}"?`)) { return; }
      chrome.runtime.sendMessage({ type: MSG.SCHEDULE_DELETE, id: schedule.id }, () => {
        renderLibrary(librarySearch.value.trim());
      });
    });

    return el;
  }

  return { renderMonitorsTab, handleScheduleDue, postScheduleWebhook, recordMonitorOutcome };
}
