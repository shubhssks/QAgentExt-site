/**
 * @fileoverview Command autocomplete module (v1.7 F1).
 *
 * Owns the command-input suggestion dropdown: building the candidate list from
 * the parser's supported commands plus the saved library, keyboard navigation,
 * and selection. Self-contained — it keeps its own selection state and reaches
 * back into the panel only for run state and to trigger a run.
 */

import { getSupportedCommands } from '../../src/engine/parser.js';

/**
 * @param {Object} ctx  Panel context.
 * @param {() => boolean} ctx.isRunning
 * @param {() => boolean} ctx.isRecording
 * @param {() => void} ctx.onRun          Trigger a run for the current command.
 * @param {string} ctx.storageKey         localStorage key holding the library.
 * @param {{ commandInput: HTMLTextAreaElement, autocompleteDropdown: HTMLElement }} ctx.elements
 */
export function createAutocompleteModule(ctx) {
  const { isRunning, isRecording, onRun, storageKey, elements } = ctx;
  const { commandInput, autocompleteDropdown } = elements;

let autocompleteIndex = -1;
let autocompleteOptions = [];

function updateAutocomplete() {
  const query = commandInput.value.trim().toLowerCase();
  autocompleteIndex = -1;
  autocompleteOptions = [];
  autocompleteDropdown.innerHTML = '';

  if (!query || isRunning() || isRecording()) {
    autocompleteDropdown.hidden = true;
    return;
  }

  const templates = getSupportedCommands().map(c => ({ text: c, type: 'template' }));

  let libraryItems = [];
  try {
    const raw = localStorage.getItem(storageKey);
    if (raw) {
      const parsed = JSON.parse(raw);
      libraryItems = Object.keys(parsed).map(key => ({ text: parsed[key].command || key, type: 'saved' }));
    }
  } catch {
    /* ignore parse errors for non-existent library */
  }

  // Combine and filter
  const allOptions = [...templates, ...libraryItems];
  autocompleteOptions = allOptions.filter(o => o.text.toLowerCase().includes(query)).slice(0, 8);

  if (autocompleteOptions.length === 0) {
    autocompleteDropdown.hidden = true;
    return;
  }

  autocompleteOptions.forEach((opt) => {
    const item = document.createElement('div');
    item.className = 'autocomplete-item';
    item.innerHTML = `
      <span class="autocomplete-item__text">${opt.text}</span>
      <span class="autocomplete-item__type">${opt.type}</span>
    `;
    item.addEventListener('click', () => {
      commandInput.value = opt.text;
      autocompleteDropdown.hidden = true;
      commandInput.focus();
    });
    autocompleteDropdown.appendChild(item);
  });

  autocompleteDropdown.hidden = false;
}

function renderAutocompleteSelection() {
  const items = autocompleteDropdown.querySelectorAll('.autocomplete-item');
  items.forEach((item, i) => {
    if (i === autocompleteIndex) {
      item.classList.add('selected');
      item.scrollIntoView({ block: 'nearest' });
    } else {
      item.classList.remove('selected');
    }
  });
}

commandInput.addEventListener('input', () => {
  updateAutocomplete();
});

commandInput.addEventListener('blur', () => {
  setTimeout(() => { autocompleteDropdown.hidden = true; }, 200);
});

commandInput.addEventListener('focus', updateAutocomplete);

commandInput.addEventListener('keydown', (e) => {
  if (!autocompleteDropdown.hidden) {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      autocompleteIndex = Math.min(autocompleteIndex + 1, autocompleteOptions.length - 1);
      renderAutocompleteSelection();
      return;
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      autocompleteIndex = Math.max(autocompleteIndex - 1, -1);
      renderAutocompleteSelection();
      return;
    } else if (e.key === 'Enter') {
      if (autocompleteIndex >= 0) {
        e.preventDefault();
        commandInput.value = autocompleteOptions[autocompleteIndex].text;
        autocompleteDropdown.hidden = true;
        return;
      }
    } else if (e.key === 'Escape') {
      autocompleteDropdown.hidden = true;
      return;
    }
  }

  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    autocompleteDropdown.hidden = true;
    onRun();
  }
});

  return { updateAutocomplete };
}
