/**
 * @fileoverview Library 'Tests' tab renderer (v1.7 F1).
 *
 * Renders the saved-test list: filtering, tag/folder narrowing, sorting and the
 * per-test actions. It RENDERS and raises intents — every mutation of panel
 * state (deleting a test, adding one to a suite, persisting the library) is a
 * callback the panel owns, which is why this module touches no chrome.* API.
 */

import { summarizeAssertionSteps } from '../../src/engine/assertions.js';

function testMatchesLibraryFilter(test, filter) {
  const query = filter.toLowerCase();
  const tags = Array.isArray(test.tags) ? test.tags : [];
  return [test.name, test.command, test.folder, ...tags]
    .filter(Boolean)
    .some(value => String(value).toLowerCase().includes(query));
}

function sortLibraryTests(tests) {
  return [...tests].sort((a, b) => {
    if (!!a.favorite !== !!b.favorite) {
      return a.favorite ? -1 : 1;
    }
    return String(b.id || '').localeCompare(String(a.id || ''));
  });
}


/**
 * @param {Object} ctx  Panel context.
 * @param {() => Array<Object>} ctx.getLibrary
 * @param {() => Array<Object>} ctx.getSuites
 * @param {() => Set<string>|Array<string>} ctx.getAffectedTestIds
 * @param {(filter?: string) => void} ctx.onRerender
 * @param {(testId: string) => Promise<void>} ctx.onDeleteTest
 * @param {(test: Object, suiteIndex: number) => void} ctx.onAddToSuite
 * @param {() => Promise<void>} ctx.persistLibrary
 * @param {(test: Object) => void} ctx.openCiHandoffModal
 * @param {(test: Object) => void} ctx.saveAsBlock
 * @param {(steps: Array<Object>) => void} ctx.showPreview
 * @param {(command: string, steps: Array<Object>, skipClear: boolean, testId: string) => void} ctx.startActualRun
 * @param {(entry: Object) => void} ctx.appendLog
 * @param {(text: string) => string} ctx.escapeHtml
 * @param {Object} ctx.elements
 */
export function createLibraryTestsModule(ctx) {
  const {
    getLibrary, getSuites, getAffectedTestIds, getRunHistory,
    onRerender, onDeleteTest, onAddToSuite, persistLibrary, onLoadTest, onRunTest,
    openCiHandoffModal, saveAsBlock, escapeHtml, elements, onEditData,
  } = ctx;
  const { libraryContainer, libraryEmpty, librarySearch, libraryTagFilter, btnRunFiltered, btnCompareRuns } = elements;

  /** @param {string} filter */
  function renderTestsTab(filter) {
    const tagFilter = libraryTagFilter ? libraryTagFilter.value.trim().toLowerCase() : '';
    let filtered = filter ? getLibrary().filter(t => testMatchesLibraryFilter(t, filter)) : getLibrary();

    if (tagFilter) {
      filtered = filtered.filter(t => {
        const tags = Array.isArray(t.tags) ? t.tags : [];
        const normalized = tagFilter.replace('#', '');
        return tags.some(tag => tag.toLowerCase().includes(normalized))
          || String(t.folder || '').toLowerCase().includes(normalized);
      });
    }
    filtered = sortLibraryTests(filtered);

    if (btnRunFiltered) {
      btnRunFiltered.style.display = (filtered.length > 0 && (filter || tagFilter)) ? 'block' : 'none';
    }
    if (btnCompareRuns) {
      btnCompareRuns.style.display = 'none';
    }

    filtered.forEach(test => {
      const assertionSummary = summarizeAssertionSteps(test.steps || []);
      const isAffected = getAffectedTestIds().has(test.id);
      const affectedBadge = isAffected ? '<span class="result__badge result__badge--critical" title="DOM elements for this test have changed significantly or are missing.">[!] Likely Affected</span>' : '';

      const testHistory = getRunHistory().filter(h => h.testId === test.id);
      const recentHistory = testHistory.slice(0, 10).reverse();

      let statsHtml = '';
      if (testHistory.length > 0) {
        const failCount = testHistory.filter(h => h.status === 'fail').length;
        const failRate = Math.round((failCount / testHistory.length) * 100);
        const validDurations = testHistory.map(h => h.duration).filter(d => typeof d === 'number' && d > 0);
        const avgDuration = validDurations.length > 0
          ? Math.round(validDurations.reduce((a, b) => a + b, 0) / validDurations.length)
          : 0;

        statsHtml = `
          <div class="library-item__stats">
            <span class="stat-badge ${failRate > 20 ? 'stat-badge--warn' : ''}" title="Fail rate over all recorded runs">ðŸ“‰ ${failRate}% failure</span>
            ${avgDuration > 0 ? `<span class="stat-badge" title="Average execution time">âš¡ ${avgDuration}ms</span>` : ''}
          </div>
        `;
      }

      let sparklineHtml = '';
      if (recentHistory.length > 0) {
        sparklineHtml = `<div class="library-item__sparkline" title="Last ${recentHistory.length} runs">` +
          recentHistory.map(h => `<div class="spark-dot spark-dot--${h.status}"></div>`).join('') +
          `</div>`;
      }

      const el = document.createElement('div');
      el.className = `library-item${test.favorite ? ' library-item--favorite' : ''}`;
      const folderText = test.folder ? ` \u00B7 ${test.folder}` : '';
      el.innerHTML = `
        <div class="library-item__main">
          <strong>${test.favorite ? '[Favorite] ' : ''}${escapeHtml(test.name)}</strong> ${affectedBadge}<br>
          <small>${escapeHtml(test.command)}</small><br>
          <small>${assertionSummary.total} assertion${assertionSummary.total === 1 ? '' : 's'}${escapeHtml(folderText)}${test.tags?.length ? ' \u00B7 ' + escapeHtml(test.tags.map(t => '#' + t).join(' ')) : ''}</small>
          ${statsHtml}
          ${sparklineHtml}
        </div>
        <div class="library-item__actions">
          <button class="btn--icon ${test.favorite ? 'library-item__favorite--active' : ''}" title="Toggle Favorite" data-action="favorite">*</button>
          <button class="btn--icon" title="Run Test" data-action="run">â-¶ï¸</button>
          <button class="btn btn--ghost btn--small" type="button" title="Edit test data" data-action="data">Data${test.dataSet?.rows?.length ? ` (${test.dataSet.rows.length})` : ''}</button>
          <button class="btn--icon" title="Set Folder" data-action="folder">F</button>
          <button class="btn--icon" title="Hand off to CI" data-action="ci-handoff">CI</button>
          <button class="btn--icon" title="Manage Tags" data-action="tags">ðŸ·ï¸</button>
          <button class="btn--icon" title="Save as Block" data-action="block">\u1F4E9</button>
          <button class="btn--icon" title="Add to Suite" data-action="add-suite">ðŸ“</button>
          <button class="btn--icon" title="Delete Test" data-action="delete">ðŸ-‘ï¸</button>
        </div>
      `;

      el.querySelector('.library-item__main')?.addEventListener('click', () => {
        onLoadTest(test);
      });

      el.querySelector('[data-action="run"]')?.addEventListener('click', (e) => {
        e.stopPropagation();
        onRunTest(test);
      });

      el.querySelector('[data-action="data"]')?.addEventListener('click', (e) => {
        e.stopPropagation();
        onEditData(test);
      });

      el.querySelector('[data-action="favorite"]')?.addEventListener('click', async (e) => {
        e.stopPropagation();
        test.favorite = !test.favorite;
        await persistLibrary();
        onRerender(librarySearch.value.trim());
      });

      el.querySelector('[data-action="ci-handoff"]')?.addEventListener('click', (e) => {
        e.stopPropagation();
        openCiHandoffModal(test);
      });

      el.querySelector('[data-action="folder"]')?.addEventListener('click', async (e) => {
        e.stopPropagation();
        const nextFolder = prompt(`Folder for "${test.name}":`, test.folder || '');
        if (nextFolder !== null) {
          test.folder = nextFolder.trim();
          await persistLibrary();
          onRerender(librarySearch.value.trim());
        }
      });

      el.querySelector('[data-action="tags"]')?.addEventListener('click', (e) => {
        e.stopPropagation();
        const currentTags = Array.isArray(test.tags) ? test.tags.join(', ') : '';
        const newTags = prompt(`Manage tags for "${test.name}":`, currentTags);
        if (newTags !== null) {
          test.tags = newTags.split(',').map(t => t.trim()).filter(Boolean);
          persistLibrary();
          onRerender();
        }
      });

      el.querySelector('[data-action="block"]')?.addEventListener('click', (e) => {
        e.stopPropagation();
        const bname = prompt('Save this test as a reusable block (name):', test.name.replace(/\s+/g, ''));
        if (bname) { saveAsBlock(bname, test.steps); }
      });

      el.querySelector('[data-action="add-suite"]')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (getSuites().length === 0) {
          alert('No suites available. Please create a suite first in the Suites tab.');
          return;
        }
        const suiteNames = getSuites().map((s, i) => `${i + 1}. ${s.name}`).join('\n');
        const choice = prompt(`Enter the number of the suite to add "${test.name}" to:\n\n${suiteNames}`);
        if (!choice) { return; }
        const index = parseInt(choice, 10) - 1;
        if (getSuites()[index]) {
          onAddToSuite(test, index);
        }
      });

      el.querySelector('[data-action="delete"]')?.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (confirm(`Delete test "${test.name}"?`)) {
          await onDeleteTest(test.id);
        }
      });

      libraryContainer.appendChild(el);
    });
    libraryEmpty.style.display = filtered.length ? 'none' : 'block';
  }

  return { renderTestsTab };
}
